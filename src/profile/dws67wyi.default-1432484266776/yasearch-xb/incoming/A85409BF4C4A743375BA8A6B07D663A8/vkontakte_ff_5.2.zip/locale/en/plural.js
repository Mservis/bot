EXPORTED_SYMBOLS = ['module'];

var module = function (application) {
    var getPluralForm = function(/* Number */ number, /* Array */ forms) {
        // for English language
        if(1 === number) {
            return forms[0];
        }
        return forms[1];
    };
    return getPluralForm;
};
