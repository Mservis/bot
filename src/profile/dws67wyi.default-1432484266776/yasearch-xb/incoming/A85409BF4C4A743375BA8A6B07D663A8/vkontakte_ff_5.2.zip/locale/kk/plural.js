EXPORTED_SYMBOLS = ['module'];

var module = function (application) {
    var getPluralForm = function(/* Number */ number, /* Array */ forms) {
        // for Kazakh language
        return forms[0];
    };
    return getPluralForm;
};
