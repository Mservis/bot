EXPORTED_SYMBOLS = ['module'];

var module = function (application) {
    var getPluralForm = function(/* Number */ number, /* Array */ forms) {
        // for Russian language
        var n10 = number % 10;

        if ((n10 == 1) && ((number == 1) || (number > 20))) {
            return forms[0];
        } else if ((n10 > 1) && (n10 < 5) && ((number > 20) || (number < 10))) {
            return forms[1];
        } else {
            return forms[2];
        }
    };
    return getPluralForm;
};
