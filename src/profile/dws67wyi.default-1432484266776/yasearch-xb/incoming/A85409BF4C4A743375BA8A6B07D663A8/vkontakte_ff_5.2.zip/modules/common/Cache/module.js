'use strict';

let EXPORTED_SYMBOLS = ["module"];

let module = function(api) {

    var filesAPI = api.Files;
    var log = function(message) {
        api.logger.debug('[Cache] ' + message);
    };

    function Cache(fileName) {
        this._fileName = fileName;
        this._data = {__proto__: null};
        this._loaded = false;
        this.__file = null;
    }

    Cache.prototype = {
        constructor: Cache,

        get _file() {
            if(null === this.__file) {
                this.__file = filesAPI.getWidgetStorage(true);
                this.__file.append(this._fileName);
            }
            return this.__file;
        },

        _load: function() {
            log('Trying to load data from ' + this._fileName);
            let file = this._file;
            try {
                let text = filesAPI.readTextFile(file);
                let object = JSON.parse(text);
                for(var i in object) {
                    this._data[i] = object[i];
                }
            }
            catch(e) {
                log('Error occurred while reading from ' + this._fileName);
            }
            this._loaded = true;
        },

        _save: function() {
            log('Write data to ' + this._fileName);

            let file = this._file;
            let string = JSON.stringify(this._data);
            filesAPI.writeTextFile(file, string);
        },

        get: function(key) {
            if(!this._loaded) {
                this._load();
            }
            let value = this._data[key] || null;
            return value;
        },

        put: function(key, value) {
            if('string' !== typeof value) {
                throw TypeError('Only strings can be saved in cache.');
            }

            log('Save ' + key + ' => ' + value);

            this._data[key] = value;
            this._save();
        },

        clear: function() {
            log('Clear.');
            this._data = {};
            this._save();
        }
    };

    return Cache;
};

if('undefined' !== typeof exports) {
    exports.module = module;
}
