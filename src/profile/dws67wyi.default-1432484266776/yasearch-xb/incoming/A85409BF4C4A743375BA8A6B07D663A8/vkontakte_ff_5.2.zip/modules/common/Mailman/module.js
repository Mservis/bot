'use strict';

let EXPORTED_SYMBOLS = ["module"];

let module = function(api) {

    const MODULE_NAME = 'Mailman';

    var log = function(message) {
        api.logger.debug('[' + MODULE_NAME + '] ' + message);
    };

    var Mailman = function(prefix) {
        if(this._prefixExists(prefix)) {
            throw Error( MODULE_NAME + ' instance with such prefix ("' + prefix + '") already exists.');
        }

        this._prefix = prefix;
        this._prefixes.push(this._prefix);
        this._proxies = {__proto__: null};
    };

    Mailman.prototype = {
        constructor: Mailman,

        _prefixes: [],

        __observerService: null,
        get _observerService() {
            return this.__observerService
                ? this.__observerService
                : this.__observerService = Components.classes["@mozilla.org/observer-service;1"]
                                            .getService(Components.interfaces.nsIObserverService);
        },

        _getLocalSubject: function(subject) {
            return this._prefix + subject;
        },

        addSubscriber: function({subscriber: subscriber, subject: _subject}) {
            let subject = this._getLocalSubject(_subject);
            let observer = this._proxies[subject];

            if('undefined' === typeof observer) {
                // proxy observer does not exist, let's create the new one
                observer = new ProxyObserver(_subject, subject, this._observerService);
                this._proxies[subject] = observer;
            }
            observer.addSubscriber(subscriber);
        },

        removeSubscriber: function({subscriber: subscriber, subject: _subject}) {
            let subject = this._getLocalSubject(_subject);
            let observer = this._proxies[subject];

            if('undefined' === typeof observer) {
                throw Error('There is not subscribers for "' + _subject + '" subject.');
            }

            observer.removeSubscriber(subscriber);
        },

        removeAllSubscribers: function() {
            for(let subject in this._proxies) {
                let observer = this._proxies[subject];
                observer.destroy();
                delete this._proxies[subject];
            }
        },

        send: function(params) {
            let subject, body;
            if('string' == typeof params) {
                subject = params;
                body = null;
            }
            else if('object' == typeof params) {
                subject = params.subject || '';
                body = ('undefined' != typeof params.body) ? params.body : null;
            }
            else {
                throw TypeError('Mailman.send() argument must be a string or an object.');
            }

            if(subject === '') {
               throw Error('Mailman.send() subject must non-empty string.');
            }

            let data = (null !== body) ? this._encode(body) : null;
            log('Send message with subject "' + this._getLocalSubject(subject) + '"');
            log('and body "' + data + '".');
            let observerService = this._observerService;
            observerService.notifyObservers(null, this._getLocalSubject(subject), data);
        },

        _encode: function(data) {
            if('string' == typeof data) {
                return data;
            }
            return JSON.stringify(data);
        },

        _prefixExists: function(prefix) {
            return (-1 !== this._prefixes.indexOf(prefix));
        }
    };


    var ProxyObserver = function(internalSubject, externalSubject, observerService) {
        this._internalSubject = internalSubject;
        this._externalSubject = externalSubject;
        this._observerService = observerService;
        this._subscribers = [];
        this._observes = false;
    };

    ProxyObserver.prototype = {
        constructor: ProxyObserver,
        
        addSubscriber: function(newSubscriber) {
            if('undefined' == typeof newSubscriber.receive) {
                throw Error('Subscriber must have "receive" method.');
            }

            for(var i = 0, len = this._subscribers.length; i < len; i++) {
                let subscriber = this._subscribers[i];
                if(subscriber === newSubscriber) {
                    log('Subscriber already added.');
                    return;
                }
            }

            this._subscribers.push(newSubscriber);
            if(this._subscribers.length === 1) {
                // first subscriber
                this._observerService.addObserver(this, this._externalSubject, false);
                this._observes = true;
            }
        },

        removeSubscriber: function(subscriber) {
            let subscriberIndex = this._subscribers.indexOf(subscriber);
            this._subscribers.splice(subscriberIndex, 1);
            if(this._subscribers.length === 0) {
                // no subscribers left
                this._observerService.removeObserver(this, this._externalSubject);
                this._observes = false;
            }
        },

        observe: function(subject, topic, data) {
            if(topic !== this._externalSubject) {
                log('Unexpected notification caught (topic is "' + topic + '").');
                return;
            }

            let decodedData = this._decode(data);
            for(var i = 0, len = this._subscribers.length; i < len; i++) {
                let subscriber = this._subscribers[i];
                subscriber.receive({
                    subject: this._internalSubject,
                    body: decodedData
                });
            }
        },

        destroy: function() {
            if (this._observes) {
                this._observerService.removeObserver(this, this._externalSubject);
            }
            this._subscribers = [];
        },

        _decode: function(data) {
            try {
                let decodedData = JSON.parse(data);
                return decodedData;
            }
            catch(e) {
                log('Error occurred while decoding data: ' + data);
            }
            return data;
        }
    };

    return Mailman;
};

if('undefined' !== typeof exports) {
    exports.module = module;
}
