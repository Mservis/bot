'use strict';

let EXPORTED_SYMBOLS = ["module"];

let module = function(api) {

    var log = function(message) {
        api.logger.debug('[Ajax] ' + message);
    };

    let converters = {
        "* text": String,
        "text html": true,
        "text json": JSON.parse,
        "text xml": true //FIXME
    };

    let convertResponse = function( outputType, responses, responseHeaders ) {
        let converter = converters["text " + outputType];
        if( 'text' === outputType || 'xml' === outputType) {
            return responses[outputType];
        }
        else if('undefined' == typeof converter) {
            return null;
        }
        else if(true === converter) {
            return responses['text'];
        }
        else {
            return converter(responses['text']);
        }
    };

    function Ajax()
    {
        //default settings
        this._settings = {
            background: false,
            contentType: 'application/x-www-form-urlencoded',
            data: '',
            dataType: 'html',
            error: function( request, textStatus, errorThrown ) {},
            headers: {},
            mimeType: '',
            success: function( data, textStatus, request ) {},
            timeout: 5000,
            type: 'GET',
            url: '',
            ignoreCache: false
        };
    }

    Ajax.prototype.setup = function(options) {
        let ajax = this;
        for(var i in options) {
            if('undefined' !== typeof ajax._settings[i] && options.hasOwnProperty(i)) {
                ajax._settings[i] = options[i];
            }
        }
    };

    Ajax.prototype.xhr = function(params) {
        let ajax = this;
        var i;
        let settings = {};
        for(i in ajax._settings) {
            settings[i] = ('undefined' !== typeof params[i]) ? params[i] : ajax._settings[i];
        }
        let headers = settings.headers;

        let request = Components.classes["@mozilla.org/xmlextras/xmlhttprequest;1"].createInstance(Components.interfaces.nsIXMLHttpRequest);

        // Mark request as background one
        if( settings.background ) {
            request.mozBackgroundRequest = true;
        }

        log( 'Sending ' + settings.type + ' request to ' + settings.url + '.' );
        request.open( settings.type, settings.url, true );

        // Override mime type if needed
        if ( '' !== settings.mimeType ) {
            request.overrideMimeType( settings.mimeType );
        }

        // Set up headers
        headers['Content-Type'] = settings.contentType;
        if('post' === settings.type.toLowerCase() && '' !== settings.data) {
            headers['Content-Length'] = settings.data.length;
        }
		for ( i in headers ) {
            request.setRequestHeader( i, headers[ i ] );
        }

        // Bypass cache if needed
        if( settings.ignoreCache ) {
            request.channel.loadFlags |= Components.interfaces.nsIRequest.LOAD_BYPASS_CACHE;
        }

        log( 'Sending data is\n' + settings.data );
        request.send(settings.data);

        var requestTimeout = Components.classes["@mozilla.org/timer;1"]
            .createInstance(Components.interfaces.nsITimer);
        requestTimeout.init({
            observe: function() {
                request.abort();
                settings.error( request, 'timeout' );
            }
        }, settings.timeout, Components.interfaces.nsITimer.TYPE_ONE_SHOT);

        var complete = function( status, statusText, responses, responseHeaders ) {
            if( status >= 200 && status < 300 || status === 304 ) {
                let data = convertResponse( settings.dataType, responses, responseHeaders );
                settings.success( data, statusText, request );
            }
            else if( -1 === status ) {
                let exception = statusText;
                settings.error( request, 'exception', exception );
            }
            else {
                settings.error( request, statusText, null );
            }
        };

        var callback = function() {
            let status;
            let statusText;
            let responseHeaders;
            let responses;
            let xml;

            try {
                // If callback was not yet executed and request is complete
                if (callback && request.readyState === 4) {

                    callback = undefined;
                    request.onreadystatechange = function() {
                    };
                    requestTimeout.cancel();

                    status = request.status;
                    log( 'Response status ' + status + '.' );
                    responseHeaders = request.getAllResponseHeaders();
                    responses = {};
                    xml = request.responseXML;
                    log( 'Response xml:\n' + xml );

                    // Construct response list
                    if (xml && xml.documentElement) {
                        responses.xml = xml;
                    }
                    responses.text = request.responseText;
                    log( 'Response text:\n' + responses.text );

                    // Firefox throws an exception when accessing
                    // statusText for faulty cross-domain requests
                    try {
                        statusText = request.statusText;
                    } catch(e) {
                        statusText = "";
                    }
                    log( 'Response status text "' + statusText + '".');
                }
            } catch( firefoxAccessException ) {
                complete( -1, firefoxAccessException );
            }
            
            // Call complete if needed
            if ( responses ) {
                complete( status, statusText, responses, responseHeaders );
            }
        };

        if(request.readyState === 4) {
            callback();
        }
        else {
            request.onreadystatechange = callback;
        }
    };

    Ajax.prototype.get = function(url, data, success, dataType) {
        this.xhr({
            data: data,
            dataType: dataType,
            success: success,
            type: 'GET',
            url: url
        });
    };

    Ajax.prototype.getJSON = function(url, data, success) {
        this.get(url, data, success, 'json');
    };

    Ajax.prototype.getXML = function(url, data, success) {
        this.get(url, data, success, 'xml');
    };

    Ajax.prototype.post = function(url, data, success, dataType) {
        this.xhr({
            data: data,
            dataType: dataType,
            success: success,
            type: 'POST',
            url: url
        });
    };

    return Ajax;
};

if('undefined' !== typeof exports) {
    exports.module = module;
}
