"use strict";

const EXPORTED_SYMBOLS = ["Corrector"];

const {
    classes: Cc,
    interfaces: Ci,
    results: Cr,
    utils: Cu
} = Components;

Cu.import("resource://gre/modules/XPCOMUtils.jsm");
Cu.import("resource://gre/modules/ctypes.jsm");

const MAPVK_VK_TO_VSC = 0;

const Corrector = {
    init: function Corrector_init() {
        this.englishLayout = new this.HKL()(0x04090409);
        this._loadlibraries();
    },
    
    finalize: function Corrector_finalize() {
        this._libraries["user32"].close();
    },
    
    _getSystem32LibPath: function Corrector__getSystem32LibPath(dllName) {
        let sysPath = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("SysD", Ci.nsIFile);
        sysPath.append(dllName);
        return sysPath.path; 
    },

    HKL: function Corrector_HKL() {
        return ctypes.StructType("HKL", [{"unused" : ctypes.int}]);
    },
    
    GetKeyboardLayoutList: function Corrector_GetKeyboardLayoutList() {
           return this._libraries["user32"].declare("GetKeyboardLayoutList",
                    ctypes.winapi_abi,
                    ctypes.int32_t,
                    ctypes.int32_t,
                    ctypes.voidptr_t);
    },
    
    VkKeyScanExW: function Corrector_VkKeyScanExW(struct) {
        return this._libraries["user32"].declare("VkKeyScanExW",
                ctypes.winapi_abi,
                ctypes.int16_t,
                ctypes.jschar,
                struct);
    },
    
    MapVirtualKeyW: function Corrector_MapVirtualKeyW(struct) {
        return this._libraries["user32"].declare("MapVirtualKeyW",
                ctypes.winapi_abi,
                ctypes.int32_t,
                ctypes.int,
                ctypes.int);
    },
    
    ToUnicodeEx: function Corrector_ToUnicodeEx(struct) {
        return this._libraries["user32"].declare("ToUnicodeEx",
                ctypes.winapi_abi,
                ctypes.int, // return type
                ctypes.int, // __in UINT wVirtKey,
                ctypes.int, // __in UINT wScanCode
                ctypes.char.ptr.array(),    // __in_bcount(256) CONST BYTE *lpKeyState,
                ctypes.jschar.ptr,  //__out_ecount(cchBuff) LPWSTR pwszBuff
                ctypes.int,    // __in int cchBuff
                ctypes.int,    // __in UINT wFlags,
                struct    // __in_opt HKL dwhkl
                );
    },
    
    _loadlibraries: function Corrector__loadlibraries() {
        this._libraries = {};
        this._libraries["user32"] = ctypes.open(this._getSystem32LibPath("User32.dll"));
        if (this._libraries["user32"] == null)
            throw new Error("Unable to load User32.dll library");
    },
    
    _getKeyboardLayoutList: function Corrector__getKeyboardLayoutList() {
        let layoutsCount = this.GetKeyboardLayoutList()(0, null);
        let array = new ctypes.ArrayType(this.HKL(), layoutsCount);
        let theLayouts = new array;
        this.GetKeyboardLayoutList()(layoutsCount, theLayouts.address());
        return theLayouts;
    },

    _determineCharLayout: function Corrector__determineCharLayout(char, systemLocales) {
        //TODO: сделать проверку регуляркой на альфабетик символы   if(!iswalpha(symbol)) return false;
        for (let i = 0; i < systemLocales.length; i++) {
            let hkl = new this.HKL();
            let virtualKey = this.VkKeyScanExW(hkl)(char, hkl(systemLocales[i].unused));
            if (virtualKey != -1)
                return systemLocales[i];
        }
        return null;
    },
    
    _determineTextLayout: function Corrector__determineTextLayout(aString, systemLocales) {
        let i = 0;
        while (i < aString.length) {
            var textLayout = this._determineCharLayout(aString[i++], systemLocales);
            if (textLayout != null)
                break;
        }
        
        if (textLayout == null && i == aString.length)
            return null;
        
        let layouts = { text: textLayout, alt: null};
        if (textLayout.unused != this.englishLayout.unused)
            layouts.alt = this.englishLayout;
        else if (systemLocales.length > 1) 
            layouts.alt = (textLayout.unused == systemLocales[0].unused) ? systemLocales[1] : systemLocales[0];
        
        return layouts;
    },
    
    _translateChar: function Corrector__translateChar(ch, srcLayout, dstLayout) {
        let hkl = new this.HKL();
        let virtualKey = this.VkKeyScanExW(hkl)(ch, hkl(srcLayout.unused));
        if (virtualKey == -1)
            return null;

        let scanCode = this.MapVirtualKeyW()(virtualKey, MAPVK_VK_TO_VSC);

        let hkl2 = new this.HKL()
        var buf = new new ctypes.ArrayType(ctypes.jschar, 1);
        let translated = this.ToUnicodeEx(hkl2)(virtualKey, scanCode, ctypes.char.ptr.array(255)(), buf, 1, 0, hkl2(dstLayout.unused));
        if (translated == 1)
            return buf.readString();
        return null;
    },
    
    _translateString: function Corrector__translateString(aString, srcLayout, dstLayout) {
        let resultStr = "";
        for each (let ch in aString) {
            let upper = (ch.toLowerCase() != ch);
            let ret = this._translateChar(ch, srcLayout, dstLayout);
            if (ret != null)
                resultStr += upper ? ret.toUpperCase() : ret; 
        }
        return resultStr;
    },
    
    getSwitchedLayout: function Corrector_getSwitchedLayout(aString) {
        if (aString == "" || aString == null)
            return aString;
        let systemLocales = this._getKeyboardLayoutList();
        
        let layouts = this._determineTextLayout(aString, systemLocales);

        if (layouts.alt != null && layouts.alt.unused != 0)
            return this._translateString(aString, layouts.text, layouts.alt);
            
        return aString;
    }
}
