"use strict";

const EXPORTED_SYMBOLS = ["DataProvider"];

const {
    classes: Cc,
    interfaces: Ci,
    results: Cr,
    utils: Cu
} = Components;

Cu.import("resource://gre/modules/XPCOMUtils.jsm");

const FIRST_PACKET_TIMEOUT = 200;   ///< таймаут через который мы ожидаем первую пачку данных
const NOMATCH_TIMEOUT = 400;        ///< таймаут через который мы решаем что данных нет

let DataProvider = {

    PROVIDER_NAME: "offline-places-suggest",
    DATA_SERVICE: "yaOmniBoxSuggestDataService",    
    
    _nomatchTimeout: null,
    _waitingTimer: null,
    _searchNextStringTimer: null,
    _searchingStrings: null,
    
    _debugSearchStartTime: null,
    
    init: function PlacesDataProvider_init(core) {
        this.api = core.api;
        
        Cu.import(this.api.Package.resolvePath("/native/fx/omnibox/urlengine.js"), this)
            .URLEngine.init(this.api);
        
        // TODO: Возможность задавать через настройки из чего именно нужно собирать результаты
        // ([x] история, [x] закладки, [x] подсказки и т.п.) В зависимости от выбора выставлять
        // в том числе и определённое значение браузерной настройки. Сейчас это значение всегда
        // устанавливается нами в "0", таким образом поиск "places" будет набирать результаты и
        // из истории, и из закладок.
        this.api.Settings.PrefsModule.set("browser.urlbar.default.behavior", 0);
        
        XPCOMUtils.defineLazyGetter(this, "_PlacesAutoComplete", function() {
            return Components.classesByID["{d0272978-beab-4adc-a3d4-04b76acfa4e7}"]
                             .getService(Ci.nsIAutoCompleteSearch);
        });
        
        this._providerService = this.api.Services.obtainService(this.api.componentID, this.DATA_SERVICE , this);
        if (!this._providerService)
            return;
        if (!this._providerService.registerDataProvider(this))
            return;
    },
    
    isAsync: false,
    
    observeServiceEvent: function PlacesDataProvider_observeServiceEvent(aProviderID, aServiceName, aTopic, aData) {
        if (this.DATA_SERVICE != aServiceName || this.api.componentID != aProviderID)
            return;
        
        switch (aTopic) {
            case "start-collecting":
                this._startSearch(aData);
                break;
            case "stop-collecting":
                this._stopSearch();
                break;
        }
    },
    
    _startSearch: function PlacesDataProvider_startSearch(aSearchStrings) {
        this._originalSearchStrings = aSearchStrings;
        
        this._searchingStrings = aSearchStrings.map(function(s) s.trim());
        if (this._searchingStrings.join("") === "")
            this._searchingStrings = [""];
        
        this._suggestions = [];
        
        this._debugSearchStartTime = Date.now();
        this._searchNextString();
    },
    
    _searchNextString: function PlacesDataProvider__searchNextString() {
        if (!this._searchingStrings.length) {
            this.api.logger.trace("History (places) search time: " + (Date.now() - this._debugSearchStartTime) + " ms.");
            this._PlacesAutoComplete.stopSearch();
            this._finishSearch(true);
            return;
        }
        
        let [searchString] = this._searchingStrings.splice(0, 1);
        if (this._searchNextStringTimer && searchString.length < 2) {
            this._PlacesAutoComplete.stopSearch();
            this._finishSearch(true);
            return;
        }
        
        if (this.timing == null)
            this.timing = {};
        
        this.timing[searchString] = Date.now();
        
        let that = this;
        this._searchNextStringTimer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
        this._searchNextStringTimer.initWithCallback({
            notify: function() that._PlacesAutoComplete.startSearch(searchString, "enable-actions", null, that)
        }, 5, Ci.nsITimer.TYPE_ONE_SHOT);
        
        // Случай если ответа нет очень продолжительное время заканчиваем поиск и ищем следующее значение
        this._nomatchTimeout = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
        this._nomatchTimeout.initWithCallback({
            notify: function() {
                that._PlacesAutoComplete.stopSearch();
                that._searchNextString();
            }
        }, NOMATCH_TIMEOUT, Ci.nsITimer.TYPE_ONE_SHOT);
    },
    
    _stopSearch: function PlacesDataProvider_stopSearch() {
        this._PlacesAutoComplete.stopSearch();
        this._finishSearch(false);
    },

    _finishSearch: function PlacesDataProvider__finishSearch(aNotify) {
        [ "_searchNextStringTimer",
          "_nomatchTimeout",
          "_waitingTimer"
        ].forEach(function(timerName) {
            let timer = this[timerName] || null;
            if (timer) {
                timer.cancel();
                delete this[timerName];
            }
        }, this);
        
        if (aNotify)
            this._notifyResults();
        
        delete this._originalSearchStrings;
        delete this._searchingStrings;
        delete this._suggestions;
    },
    
    _notifyResults: function PlacesDataProvider__notifyResults() {
        this._providerService.handleResponse("start-collecting", {
            originalSearchStrings: this._originalSearchStrings,
            suggestions: this._suggestions
        }, this);
    },

    _processSearchResults: function (aAutoCompleteSearch, aAutoCompleteResult) {
        if (!this._suggestions)
            return;
        
        let originalSearchString = aAutoCompleteResult.searchString;
        
        let uris = [];
        let titles = [];
        let styles = [];
        let images = [];

        let i = 0;
        
        while (i < aAutoCompleteResult.matchCount) {
            let title = aAutoCompleteResult.getCommentAt(i);
            if (title != "404") { // =((((((
				let url = this.URLEngine.validateURL(aAutoCompleteResult.getValueAt(i), originalSearchString);
                uris.push(url);
            
                titles.push(title);
                styles.push(aAutoCompleteResult.getStyleAt(i));
                images.push(aAutoCompleteResult.getImageAt(i));
            }
            i++;
        }
        let urlMatchedIndexes = this._getURLMatchedIndexes(uris, originalSearchString);
        // выбираем те заголовки у которых ввод находится на начале какого либо слова в заголовке
        let titleMatchedIndexes = this._getTitleMatchedIndexes(titles, originalSearchString);
        // фильтруем массив заголовков, так как он менее приоритетный на совпадающие с урлами индексы
        let filteredTitleMatchedIndexes =  titleMatchedIndexes.filter(function(x) {
            return (urlMatchedIndexes.indexOf(x) == -1);
        });
        
        // Собираем массивы для отдачи саджесту, выбирем только нужный максимум элементов 
        let suggestions = [];
        
        let maxLength = urlMatchedIndexes.length;
        
        for (let i = 0; i < maxLength; i++) {
            suggestions.push({
                value: uris[ urlMatchedIndexes[i] ],
                comment: titles[ urlMatchedIndexes[i] ],
                image: images[ urlMatchedIndexes[i] ],
                style: styles[ urlMatchedIndexes[i] ]
            });
        }
        
        maxLength = filteredTitleMatchedIndexes.length;
        for (let i = 0; i < maxLength; i++) {
            suggestions.push({
                value: uris[ filteredTitleMatchedIndexes[i] ],
                comment: titles[ filteredTitleMatchedIndexes[i] ],
                image: images[ filteredTitleMatchedIndexes[i] ],
                style: styles[ filteredTitleMatchedIndexes[i] ]
            });
        }
        
        this._suggestions = this._suggestions.concat(suggestions);
		this._PlacesAutoComplete.stopSearch();
		this._finishSearch(true);

    },
    
    // nsIAutoCompleteObserver
    onSearchResult: function PlacesDataProvider_onSearchResult(aAutoCompleteSearch, aAutoCompleteResult) {
        
        // Если поиск продолжается, то ждём его завершения и следующего вызова onSearchResult.
        if (aAutoCompleteResult.searchResult == Ci.nsIAutoCompleteResult.RESULT_NOMATCH_ONGOING)
            return;
			
        if (this._nomatchTimeout)
            this._nomatchTimeout.cancel();
        
        let searchTime = Date.now() - this.timing[aAutoCompleteResult.searchString];
        if (aAutoCompleteResult.searchResult == Ci.nsIAutoCompleteResult.RESULT_SUCCESS_ONGOING && searchTime < FIRST_PACKET_TIMEOUT) {
            let that = this;
            this._waitingTimer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
            this._waitingTimer.initWithCallback({
                notify: function() { 
                    that._processSearchResults(aAutoCompleteSearch, aAutoCompleteResult);
                }
            }, FIRST_PACKET_TIMEOUT - searchTime, Ci.nsITimer.TYPE_ONE_SHOT);
            
            return;
        }
        if (this._waitingTimer)
            this._waitingTimer.cancel();
        
        this._processSearchResults(aAutoCompleteSearch, aAutoCompleteResult);
    },
    
    // nsIAutoCompleteObserver
    onUpdateSearchResult: function PlacesDataProvider_onUpdateSearchResult(aAutoCompleteSearch, aAutoCompleteResult) {
    },
    
    // Выбирает индексы тех элементов у которых искомая фраза находится сразу после разделителя, пробел, табуляция и тд... 
    _getTitleMatchedIndexes: function PlacesDataProvider__getTitleMatchedIndexes(titleList, userInput) {
        let matchesIndexes = [];
        for (let i = 0, len = titleList.length; i < len; i++) {
            let item = titleList[i];
            if (item == null)
                continue;
            
            let lowerItem = item.toLowerCase(); 
            let index = this.URLEngine.hasInputPart(lowerItem, userInput, true);
            if (index == -1)
                continue;
            matchesIndexes.push(i);
        }
        
        return matchesIndexes;
    },
    
		// TODO: Пока такой ужасный вариант сортировки, обязательно подумать как быть дальше, 
		// т.к. обычный .sort в данном случае не подходит поскольку из за наших критериев сравнивает не все элементы
		_badSort: function (array, sortfunc) {
			let maxOfSwaps = array.length * array.length; //защита от взаимоисключающих условий и зависания
			for (let i = 0; i < array.length; i++) {
				for (let j = i ; j < array.length; j++) {
					let a = array[i];
					let b = array[j];
					if (sortfunc(a, b)) {
						maxOfSwaps--;
						array[i] = b;
						array[j] = a;
						j = i;
						
						if (maxOfSwaps < 0)
							return;
					}
				}
			}
		} ,
    
    // Выбирает индексы тех элементов у которых искомая фраза находится в начале домена, либо после разделителя
    _getURLMatchedIndexes: function PlacesDataProvider__getURLMatchedIndexes(values, userInput) {
        let matchesIndexes = [];
        let hostIndexes = [];
        for (let i = 0, len = values.length; i < len; i++) {
            let uri = values[i];
            
            if (this.URLEngine.isMatchedURL(uri, userInput))
                matchesIndexes.push(i);
        }
        
        // Сортируем результаты так, чтобы совпадения в начале домена стояли выше
        let that = this;    
		
		this._badSort(matchesIndexes, function(a, b) {
				let positionInA = that.URLEngine.hasInputPart(values[a], userInput);
				let positionInB = that.URLEngine.hasInputPart(values[b], userInput);
				let inputPosition = (positionInA > positionInB);
				let isSearchOrNot = (values[a].indexOf(".") == -1 && values[b].indexOf(".") != -1);
				let similarDomains = (that.URLEngine.extractDomain(values[a]) == that.URLEngine.extractDomain(values[b]));
				let isLonger = (values[a].length > values[b].length);
				let result = inputPosition || isSearchOrNot || (similarDomains && isLonger && positionInA == positionInB);
				return result;
		});
		
		/*
		matchesIndexes.sort(function(a, b) {
				let positionInA = that.URLEngine.hasInputPart(values[a], userInput);
				let positionInB = that.URLEngine.hasInputPart(values[b], userInput);
				let inputPosition = (positionInA > positionInB);
				let isSearchOrNot = (values[a].indexOf(".") == -1 && values[b].indexOf(".") != -1);
				let similarDomains = (that.URLEngine.extractDomain(values[a]) == that.URLEngine.extractDomain(values[b]));
				let isLonger = (values[a].length > values[b].length);
				let result = inputPosition || isSearchOrNot || (similarDomains && isLonger && positionInA == positionInB);
				return result;
		});
		*/
        return matchesIndexes;
    },

    // Выбирает индексы элементов не содержащихся в matchedIndexes и сортирует их по близости вхождения индекса к началу  
    _getOtherMatchedIndexes: function PlacesDataProvider__getOtherMatchedIndexes(matchedIndexes, uris, userInput) {
        let otherIndexes = [];
        
        for (let i = 0, len = uris.length; i < len; i++) {
            if (matchedIndexes.indexOf(i) == -1)
                otherIndexes.push(i);
        }
        
        otherIndexes.sort(function(a, b) {
            let indexA = uris[a].indexOf(userInput);
            let indexB = uris[b].indexOf(userInput);
            
            return ((indexA > indexB && indexB != -1) || (indexA == -1)) || (uris[b].length - uris[a].length);
        });
        
        return otherIndexes;
    }
};
