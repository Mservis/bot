"use strict";

const EXPORTED_SYMBOLS = ["URLEngine"];

const {
    classes: Cc,
    interfaces: Ci,
    results: Cr,
    utils: Cu
} = Components;

Cu.import("resource://gre/modules/XPCOMUtils.jsm");

const URLEngine = {
    init: function URLEngine_init(api) {
        this.api = api;
        //runTests();
    },
    
    finalize: function URLEngine_finalize() {
        this.api = null;
    },
    
    _hostsList: null,
    _tldList: null,
    
    _loadHostList: function URLEngine__loadHostList() {
        // {localhost:["127.0.0.1", "::1", "fe80::1%lo0"], ...}
        this._hostsList = {__proto__: null};
        
        let file = this._getHostsFile();
        if (!file)
            return;
        
        let tempList;
        try {
            tempList = this.api.Files.readTextFile(file).split("\n");
        } catch (e) {}
        
        for (let i = 0, len = tempList.length; i < len; i++) {
            let trimmedLine = tempList[i].replace(/#.+/, "").trim();
            let [ip, name] = trimmedLine.split(/\s+/);
            if (!name)
                continue;
            if (!(name in this._hostsList))
                this._hostsList[name] = [];
            this._hostsList[name].push(ip);
        }
    },
    
    _loadTLDList: function URLEngine__loadTLDList() {
        let path = this.api.Package.resolvePath("/data/tld.txt");
        let fileChannel = this.api.Package.getFileInputChannel(path);
        
        try {
            let content = this.api.StrUtils.readStringFromStream(fileChannel.contentStream);
            this._tldList = JSON.parse(content);
        } catch (e) {
            this.api.logger.error("Can't get TLD list from tld.txt");
            this._tldList = {};
        }
    },
    
    _getHostsFile: function URLEngine__getHostsFile() {
        let osName = this.api.Environment.os.name;
        let hostsFile;
        if (osName == "windows") {
            hostsFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("SysD", Ci.nsIFile);
            hostsFile.append("drivers");
        } else {
            hostsFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
            hostsFile.initWithPath("/");
            if (osName == "mac")
                hostsFile.append("private");
        }
        hostsFile.append("etc");
        hostsFile.append("hosts");
        return hostsFile.exists() && hostsFile.exists() && hostsFile;
    },
    
    get hostsList() {
        if (!this._hostsList)
            this._loadHostList();
        
        return this._hostsList;
    },

    get tldList() {
        if (!this._tldList)
            this._loadTLDList();
        
        return this._tldList;
    },

    matchHost: function URLEngine_matchHost(aHostString) {
        return (aHostString in this.hostsList);
    },
    
    matchTLD: function URLEngine_matchTLD(aDomainString) {
        return (aDomainString in this.tldList);
    },    
    
    get URIFixup() {
        delete this.URIFixup;
        return this.URIFixup = Cc["@mozilla.org/docshell/urifixup;1"].getService(Ci.nsIURIFixup);
    },
    
    get eTLDService() {
        delete this.eTLDService;
        return this.eTLDService = Cc["@mozilla.org/network/effective-tld-service;1"].getService(Ci.nsIEffectiveTLDService);
    },
    
    _checkonRubbish: /\"|\^|\'|\*|\(|\)|\=|\+|\<|\>|\@|\$|\\s|,|\!|\||%/i, //  регексп проверки на мусор в урле
    
    // Проверяет может ли, потенциально, строка являться урлом,
    // если да то возвращает true, иначе false
    weakURITest: function URLEngine_weakURITest(aString) {
        let host;
        try {
            let resultURI = this.URIFixup.createFixupURI(aString, this.URIFixup.FIXUP_FLAG_NONE);
            host = resultURI && resultURI.host;
        } catch(e) {}
        
        return host &&
               !this._checkonRubbish.test(host) &&
               host.indexOf("#") == -1 &&
               host.indexOf("?") == -1 &&
               host.lastIndexOf(".") != (host.length - 1);
    },
    
    // Проверяет является ли строка урлом
    isURL: function URLEngine_isURL(aString) {
        if (this.matchHost(aString))
            return true;
        
        let resultURI;
        try {
            resultURI = this.URIFixup.createFixupURI(aString, this.URIFixup.FIXUP_FLAG_NONE);
            if (!resultURI || !resultURI.host)
                return false;

            if (resultURI.host.indexOf(".") == -1 || this._checkonRubbish.test(resultURI.host))
                return false;
            
            let tld = this.eTLDService.getBaseDomain(resultURI);
            tld = tld.substr(tld.lastIndexOf(".") + 1); // bbc.co.uk -> uk
            return this.matchTLD(tld);
        } catch (e if e.result == Cr.NS_ERROR_HOST_IS_IP_ADDRESS) {
            // 12.12.2012 => 12.12.7.220, но нам нужны "обычные" ipv4:
            return /^((\d){1,3}\.){3}\d{1,3}$/.test(resultURI.host);
        } catch (e) {}
        
        return false;
    },
    
    // Разбивает строку input по пробелам на части и ищет их вхождения в source
    hasInputPart: function URLEngine_hasInputPart(source, input, noShortComparsion) {
        if (input == null)
            return -1;
        source = source.toLowerCase();
        input = input.toLowerCase();
        let inputParts = input.split(" ");
        
        let indexes = [];
        
        for (let i = 0, len = inputParts.length; i < len; i++) {
            let part = inputParts[i];
            if (noShortComparsion == true && part.length < 2)
                continue;
            let index = source.indexOf(part);
            if ( (index != -1) && noShortComparsion == null ) { // Вариант когда ищем в урле без опоры на ключевые точки
                indexes.push(index);
                continue;
            }
            
            if (noShortComparsion != true || index == -1)
                return -1;
           
            if ((index > 0 && this._pillarPoints.indexOf(source[index - 1]) != -1) || index == 0) // Вариант когда ищем в только по ключевым точкам
                indexes.push(index);
            else
                return -1;
        }
        
        return indexes.length ? indexes[0] : -1;
    },
    
    _pillarPoints: [".", "/", "_", " ", "-"],
    
    validateURL: function URLEngine_validateURL(spec, aString) {
        let cutScheme = spec.indexOf(aString) != 0;
        let url = (!cutScheme) ? spec : spec.replace(/^http:\/\//, "");
        let cutWww = url.indexOf(aString) != 0;
        url = (!cutWww) ? url : url.replace(/^www\./, "");
        if (url.indexOf("moz-action") != 0)
            url = url.replace(/\/$/, "");
        return url;
    },
    // Проверяет находится ли строка aString в урле url около опорных точек
    isMatchedURL: function URLEngine_isMatchedURL(url, aString) {
        let qindex = url.indexOf("?");
        let qStringIndex = aString.indexOf("?");
        let url = (qindex != -1 && qStringIndex == -1) ? url.substr(0, qindex) : url;
        let index = this.hasInputPart(url, aString);
        if (index == -1)
            return false;

        if (index == 0 || url.indexOf("moz-action") == 0 || this._pillarPoints.indexOf(url[index - 1]) != -1)
            return true;
        
        return false;
    },
    
    // Проверяет находится ли строка aString в урле url около опорных точек
    isMatchedWholeURL: function URLEngine_isMatchedWholeURL(url, aString) {
        let qindex = url.indexOf("?");
        let url = (qindex != -1) ? url.substr(0, qindex) : url;
        let index = this.hasInputPart(url, aString);

        if (index == -1)
            return false;
        if (url.indexOf("moz-action") == 0 || index == 0)
            return true;
        
        return false;
    },
    
   isMatchedArray: function URLEngine_isMatchedArray(historyArray, aString, switchedString, compareWholeDomain) {
        for (let i = 0, len = historyArray.length; i < len; i++) {
            let item = historyArray[i];
            
            let url;
            try {
                let resultURI = this.URIFixup.createFixupURI(item.value, this.URIFixup.FIXUP_FLAG_NONE);
                url = resultURI.spec;
            } catch (e) {}
            
            if (!url) continue;
            let matchedFunc = (compareWholeDomain) ? this.isMatchedWholeURL : this.isMatchedURL;
            if (matchedFunc.call(this, this.validateURL(url, aString), aString) ||
                matchedFunc.call(this, this.validateURL(url, switchedString), switchedString)) {
                return i;
            }
        }
        
        return -1;
    },
    
    extractDomain: function URLEngine_extractDomain(aURL) {
        try {
            return this.URIFixup.createFixupURI(aURL, this.URIFixup.FIXUP_FLAG_NONE).host;
        } catch(e) {}
        
        return aURL;
    },
    
    // проверяет имеет ли массив array урл value 
    hasURL: function URLEngine_hasURL(aArray, aValue) {
        let trimmedValue = aValue.replace(/\/$/, "");
        let count = 0;
		let unique = false;
        for (let i = 0, len = aArray.length; i < len; i++) {
			let valA = aArray[i].value.replace(/\/$/, "");
            let domain = this.extractDomain(trimmedValue);
            let domainA = this.extractDomain(valA);
			if (trimmedValue == valA)
				unique = true;
            if (domain == domainA)
                count++;
        }
        return [unique, count];
    },
    
    getInputType: function URLEngine_getInputType(aString, aStrictCheck) {
        function trace(str) {
            //logger.trace(str);
            //dump(str + "\n");
        }
        
        let logger = this.api.logger;
        
        trace(" --- check '" + aString + "'");
        
        let str = (aString || "").trim();
        if (!str) {
            trace("!str");
            return ["search", str];
        }
        
        let uri;
        try {
            uri = this.URIFixup.createFixupURI(aString, this.URIFixup.FIXUP_FLAG_NONE);
        } catch (e) {}
        
        if (!uri) {
            trace("!uri");
            return ["search", str];
        }
        
        let host = "";
        try {
            host = uri.host;
        } catch (e) {}
        
        trace("host: '" + host + "'");
        
        if (!host) {
            trace("uri.scheme: '" + uri.scheme + "'");
            
            if (/^(mailto|file|news|resource|about|data|bar|view-source|javascript)$/.test(uri.scheme))
                return ["url", str];
            
            let protocolHandler = Cc["@mozilla.org/network/io-service;1"]
                                      .getService(Ci.nsIIOService)
                                      .getProtocolHandler(uri.scheme);
            try {
                // TODO: ?
                protocolHandler.newChannel(uri);
            } catch (e) {
                if (e.result === Cr.NS_ERROR_UNKNOWN_PROTOCOL) {
                    if (/^[a-z]$/i.test(uri.scheme)) // "c://windows/"
                        return ["url", "file:///" + uri.spec];
                    
                    trace("unknown protocol '" + uri.scheme + "'");
                    return ["maybeurl", str];
                }
            }
            trace("no host");
            
            if (/\/[;?]/.test(uri.path)) {
                return ["search", str];
            }
            
            return ["url", uri.spec];
        }
        
        if (host.length > 255) {
            trace("host.length > 255");
            return ["search", str];
        }
        
        if (aStrictCheck) {
            let hostParts = host.split(".");
            for (let i = hostParts.length; --i >= 0;) {
                let part = hostParts[i];
                if (!part ||
                    part.length > 63 ||
                    /^\-|\-$/.test(part))
                {
                    trace("bad host part");
                    return ["search", str];
                }
            }
        }
        
        if (/^(https?|ftp|xb|chrome):\/\//.test(str)) { // str, не uri.scheme!
            trace("/^(https?|ftp|xb|chrome):\\\/\\\//.test('" + str + "')");
            return ["url", uri.spec];
        }
        
        try {
            let baseDomain = this.eTLDService.getBaseDomain(uri);
            trace("baseDomain: '" + baseDomain + "'");
            let tld = baseDomain.substr(baseDomain.lastIndexOf(".") + 1); // bbc.co.uk -> uk
            
            let parts = uri.host.split(".");
            let likeTLD = parts.pop();
            let likePart = parts.pop();
            
            if (likeTLD && likePart) {
                if ((/[\u0400-\u052f]/.test(likeTLD) && /[a-z]/i.test(likePart)) ||
                    ((/[\u0400-\u052f]/.test(likePart) || likePart.indexOf("xn--") == 0) && /[a-z]/i.test(likeTLD))) {
                    trace("different langs in part ('" + likePart + "') and tld ('" + likeTLD + "')");
                    return ["maybeurl", uri.spec];
                }
            }
            
            if (this.matchTLD(tld)) {
                trace("matchTLD");
                return ["url", uri.spec];
            }
            
            if (tld.indexOf("xn--") == 0) {
                if (this.api.Settings.PrefsModule.has("network.IDN.whitelist." + tld))
                    return ["url", uri.spec];
                if (aStrictCheck)
                    return ["search", str];
            } else if (aStrictCheck) {
                if (!/^[a-z]+$/i.test(tld)) {
                    trace("bad tld");
                    return ["search", str];
                }
            }
            
        } catch (e if e.result == Cr.NS_ERROR_HOST_IS_IP_ADDRESS) {
            if (str[0] == "[" || /^((\d){1,3}\.){3}\d{1,3}(:\d*)?(\/|$)/.test(host)) {
                trace("is ip");
                return ["url", uri.spec];
            } else {
                trace("is not full ip");
                return ["search", str];
            }
        } catch (e) {}
        
        if (aStrictCheck) {
            let aceHost;
            try {
                aceHost = Cc["@mozilla.org/network/idn-service;1"]
                              .getService(Ci.nsIIDNService)
                              .convertUTF8toACE(host);
                trace("aceHost: " + aceHost);
            } catch (e) {
                trace("convertUTF8toACE error");
                return ["search", str];
            }
            
            // RFC 952: [a-z0-9-], начинается с [a-z], не должно заканчиваться "-".
            // RFC 1123: допускает начало с цифры
            let hostParts = aceHost.split(".");
            for (let i = hostParts.length; --i >= 0;) {
                let part = hostParts[i];
                if (!part ||
                    /^\-|\-$/.test(part) ||
                    !/^[a-z0-9\-]+$/i.test(part))
                {
                    trace("bad ACE host part");
                    return ["search", str];
                }
            }
        }
        
        if (/\/;/.test(uri.path)) {
            return ["search", str];
        }
        
        if (uri.path == "/") {
            if (str.substr(-1) == "/")
                return ["url", uri.spec];
        } else {
            if (!/%20/.test(uri.path.split("?")[0]))
                return ["url", uri.spec];
        }
        
        return ["maybeurl", uri.spec];
    }
}

function runTests() {
    function strictAssert(aString, aResult) {
        assert(aString, aResult, true);
    }
    
    function assert(aString, aResult, aStrictCheck) {
        let result = URLEngine.getInputType(aString, aStrictCheck);
        let res = [].concat(aResult);
        
        if (res[1] === null)
            res[1] = result[1];
        
        if (result.join("|||") != res.join("|||")) {
            let msg = "\n\n======================= [FAIL] ========================================\n" +
                      "Input: '" + aString + "'\n" +
                      "Res: '" + result + "'\n" +
                      "Exp: '" + res + "'\n" +
                      "\n\n";
            dump(msg + "\n");
        }
    }
    
    runTests = function() {};
    
    const UConverter = Cc["@mozilla.org/intl/scriptableunicodeconverter"].createInstance(Ci.nsIScriptableUnicodeConverter);
    UConverter.charset = "UTF-8";
    
    function u(str) UConverter.ConvertToUnicode(str);
    
    let urlres = ["url", null];
    let searchres = ["search", null];
    let maybeurlres = ["maybeurl", null];
    
    assert("", ["search", ""]);
    
    assert("lllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll63", // 63
         maybeurlres);
    
    assert("llllllllllllllllllllllllllllllllllllllllllllllllllllllllll60."
         + "60llllllllllllllllllllllllllllllllllllllllllllllllllllllllll",
         maybeurlres);
    
    assert("llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll64", // 64
         maybeurlres);
    
    assert("llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll64."
         + "llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll64", // 64
         maybeurlres);
    
    strictAssert("llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll64", // 64
         searchres);
    
    strictAssert("llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll64."
         + "llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll64", // 64
         searchres);
    
    assert("lllllllllllllllllllllllllllllllllllllllllllllllll."
         + "lllllllllllllllllllllllllllllllllllllllllllllllll."
         + "lllllllllllllllllllllllllllllllllllllllllllllllll."
         + "lllllllllllllllllllllllllllllllllllllllllllllllll."
         + "lllllllllllllllllllllllllllllllllllllllllllllllll."
         + "lllll", // 255
         maybeurlres);
    
    assert("lllllllllllllllllllllllllllllllllllllllllllllllll."
         + "lllllllllllllllllllllllllllllllllllllllllllllllll."
         + "lllllllllllllllllllllllllllllllllllllllllllllllll."
         + "lllllllllllllllllllllllllllllllllllllllllllllllll."
         + "lllllllllllllllllllllllllllllllllllllllllllllllll."
         + "llllll", // 256
         ["search", null]);
    
    assert("staff.ru", ["url", "http://staff.ru/"]);
    
    assert(u("президент"), ["maybeurl", "http://xn--d1abbgf6aiiy/"]);
    assert(u("президент.рффф"), maybeurlres);
    
    assert(u("президент.рф"), ["url", u("http://президент.рф/")]);
    assert(u("президент.рффф.рф"), ["url", u("http://президент.рффф.рф/")]);
    
    assert(u("ПРЕЗИДЕНТ.РФ"), ["url", u("http://президент.рф/")]);
    assert(u("ПРЕЗИДЕНТ.РФФФ.РФ"), ["url", u("http://президент.рффф.рф/")]);
    
    assert(u("2128506.рф"), ["url", u("http://2128506.рф/")]);
    assert(u("blog.рф"), ["maybeurl", u("http://blog.рф/")]);
    assert(u("blog.президент.рф"), ["url", u("http://blog.президент.рф/")]);
    assert(u("123.ua"), ["url", u("http://123.ua/")]);
    assert(u("однок.ru"), maybeurlres);
    assert(u("одноклассники.ua"), ["maybeurl", u("http://одноклассники.ua/")]);
    assert(u("Ё.ua"), ["maybeurl", u("http://ё.ua/")]);
    assert(u("одноклассники.example.ua"), ["url", u("http://одноклассники.example.ua/")]);
    
    assert("ijuh.tr", ["maybeurl", "http://ijuh.tr/"]);
    assert("http://ijuh.tr", ["url", "http://ijuh.tr/"]);
    assert("sdafdsfs.tr", ["maybeurl", "http://sdafdsfs.tr/"]);
    strictAssert("sdafdsfs.tr", ["maybeurl", "http://sdafdsfs.tr/"]);
    assert("nic.tr", ["url", "http://nic.tr/"]);
    assert("http://nic.tr", ["url", "http://nic.tr/"]);
    strictAssert("http://nic.tr", ["url", "http://nic.tr/"]);
    
    assert(u("search search"), ["search", "search search"]);
    assert(u("поиск поиск"), ["search", u("поиск поиск")]);
    
    assert("123", searchres);
    assert("123.", searchres);
    assert("123.123", searchres);
    assert("123.123.", searchres);
    assert("123.123.123", searchres);
    assert("123.123.123.", searchres);
    assert("123.123.123.123", ["url", "http://123.123.123.123/"]);
    assert("123.123.123.123:8080", ["url", "http://123.123.123.123:8080/"]);
    assert("123.123.123.123.", searchres);
    assert("123.123.123.123.:8080", searchres);
    assert("123.123.123.123.123", maybeurlres);
    
    strictAssert("123.123.123.123.123", searchres);
    
    assert("-abc.com", urlres);
    assert("abc-.com", urlres);
    
    strictAssert("-abc.com", searchres);
    strictAssert("abc-.com", searchres);
    
    assert("abc-cba.com", ["url", "http://abc-cba.com/"]);
    assert("1abc.com", ["url", "http://1abc.com/"]);
    
    strictAssert("abc-cba.com", ["url", "http://abc-cba.com/"]);
    strictAssert("1abc.com", ["url", "http://1abc.com/"]);
    
    // mailto, file, news, socks, res, about, data, xb, bar, view-source, wyciwyg, resource, chrome, javascript
    
    assert("mailto:mash-funky@mail.ru", ["url", "mailto:mash-funky@mail.ru"]);
    assert("file:", ["url", "file:"]);
    assert("file://c:/program files", ["url", "file://c:/program files"]);
    assert("news:", ["url", "news:"]);
    //assert("socks:", ["url", "socks:"]); // Нет в Fx
    //assert("res:", ["url", "res:"]); // Нет в Fx
    assert("about:", ["url", "about:"]);
    assert("about:about", ["url", "about:about"]);
    assert("bar:welcome", ["url", "bar:welcome"]);
    assert("data:text/html,hello", ["url", "data:text/html,hello"]);
    assert("xb://toolkit/images/throbber.gif", ["url", "xb://toolkit/images/throbber.gif"]);
    assert("resource:", ["url", "resource:"]);
    
    assert("javascript:1+2", ["url", "javascript:1+2"]);
    
    assert("view-source:data:text/html;charset=utf-8,source", urlres);
    
    assert("notexists:text/html,hello", maybeurlres);
    
    assert("chrome://yabar/content/index.xul", urlres);
    
    assert("staff", maybeurlres);
    assert("localhost", maybeurlres);
    
    assert("staff/", urlres);
    assert("localhost/", urlres);
    
    assert("staff/staff", urlres);
    assert("localhost/some/path", urlres);
    assert("localhost/some/path/", urlres);
    
    assert("http://yandex.ru/", urlres);
    assert("http://yandex/", urlres);
    assert("http://yandex.ru.ru/", urlres);
    assert("http://yandex.ru", urlres);
    assert("http://yandex", urlres);
    assert("http://yandex.ru.ru", urlres);
    
    assert("yandex.ru/?foo", urlres);
    assert("http://yandex.ru/?foo", urlres);
    assert("yandex.ru/?foo=bar", urlres);
    assert("http://yandex.ru/?foo=bar", urlres);
    assert("yandex.ru/baz?foo=bar", urlres);
    assert("http://yandex.ru/baz?foo=bar", urlres);
    assert("yandex.ru/#ref", urlres);
    assert("http://yandex.ru/#ref", urlres);
    assert("yandex.ru/baz?foo=bar#ref", urlres);
    assert("http://yandex.ru/baz?foo=bar#ref", urlres);
    
    assert("http:/www.yandex.ru", urlres);
    assert("http:///www.yandex.ru", urlres);
    
    assert("ftp://ya.ru", urlres);
    assert("ftp://staff", urlres);
    
    assert("ps/2 games", maybeurlres);
    assert("yes/no", urlres);
    assert("50/50", searchres);
    
    assert(u("staff/привет"), urlres);
    strictAssert(u("staff/привет"), urlres);
    assert(u("hh/рф"), urlres);
    strictAssert(u("hh/рф"), urlres);
    
    assert("twitter.com/#!/user", urlres);
    assert("http://twitter.com/#!/user", urlres);
    
    assert("user@example.com", urlres);
    assert("user:pass@example.com", maybeurlres);
    assert("user:pass@example.com/", maybeurlres);
    assert("user:pass@example.com/pathname", maybeurlres);
    assert("user:pass@example.com/pathname/", maybeurlres);
    assert("user:pass@example.com/pathname#ref", maybeurlres);
    
    assert("http://user@example.com", urlres);
    assert("http://user:pass@example.com", urlres);
    assert("http://user:pass@example.com/", urlres);
    assert("http://user:pass@example.com/pathname", urlres);
    assert("http://user:pass@example.com/pathname/", urlres);
    assert("http://user:pass@example.com/pathname#ref", urlres);
    
    assert("file:///C:\\", urlres);
    assert("file:///C:\\WINDOWS\\file.html", urlres);
    assert("file:///C:/", urlres);
    assert("file:///c://windows", ["url", "file:///c://windows"]);
    assert("file:///C:/WINDOWS/file.html", urlres);
    assert("file:///Users/.localized", urlres);
    assert("file:///", urlres);
    assert("file://u/", urlres);
    
    assert(";;;;;;", ["search", ";;;;;;"]);
    strictAssert(";;;;;;", ["search", ";;;;;;"]);
    assert("asdasd;asd", ["search", "asdasd;asd"]);
    strictAssert("asdasd;asd", ["search", "asdasd;asd"]);
    assert("...,,,...", maybeurlres);
    strictAssert("...,,,...", ["search", "...,,,..."]);
    
    assert("???????", ["search", "???????"]);
    strictAssert("???????", ["search", "???????"]);
    
    assert("/Users", ["url", "/Users"]);
    //assert("//windows", searchres);
    //assert("//windows/", urlres);
    //assert("//server/path", ["url", "//server/path"]);
    assert("c://program files", ["url", "file:///c://program%20files"]);
    
    assert("host?test", urlres);
    assert("ya.ru?test", urlres);
    
    assert("host#", urlres);
    assert("host#test", urlres);
    assert("ya.ru#", urlres);
    assert("ya.ru#test", urlres);
    
    assert("host+host", maybeurlres);
    assert("host^host", maybeurlres);
    assert("host!host", maybeurlres);
    
    strictAssert("host+host", searchres);
    strictAssert("host^host", searchres);
    strictAssert("host!host", searchres);
    
    dump("\n\n *** tests done.\n\n");
}
