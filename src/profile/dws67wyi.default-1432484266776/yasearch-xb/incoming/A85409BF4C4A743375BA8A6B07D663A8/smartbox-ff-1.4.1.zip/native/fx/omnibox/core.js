"use strict";

const EXPORTED_SYMBOLS = ["core", "resources"];

const {
    classes: Cc,
    interfaces: Ci,
    results: Cr,
    utils: Cu
} = Components;

const resources = {
    browser: {
        styles: ["/native/fx/omnibox/browser.css"],
        urlBarItems: { button: 10100 }
    }
};

const WIDGET_ID = "http://bar.yandex.ru/packages/yandexbar#omnibox";

const PARTNER_PACK_COMPID = "ru.yandex.custombar.branding";
const PARTNER_PACK_SVCNAME = "package";

const DEFAULT_QUERY_CHARSET = "ISO-8859-1";

const core = {
    api: null,
    
    init: function OmniBox_init(api) {
        this.api = api;
        
        this._brandingService = api.Services.obtainService(PARTNER_PACK_COMPID, PARTNER_PACK_SVCNAME, this);
        
        this.lockKeywordURLPrefs();
        
        Cu.import(api.Package.resolvePath("/native/fx/omnibox/searchController.js"), this)
            .OmniBox.init(this);
        
        this._manageUserChromeCSS(true);
    },
    
    finalize: function OmniBox_finalize() {
        this._manageUserChromeCSS(false);
        
        this.unlockKeywordURLPrefs();
        this.OmniBox.finalize();
        
        this.api.Services.releaseService(PARTNER_PACK_COMPID, PARTNER_PACK_SVCNAME, this);
        this._brandingService = null;
        
        this.api = null;
    },
    
    initURLBarItem: function OmniBox_initURLBarItem(itemElement, itemClass) {
        this._showWelcomePageOnStart();
        return new OmniBoxUBItem(itemElement, itemClass, this);
    },
    
    observeServiceEvent: function OmniBox_observeServiceEvent(aProviderID, aServiceName, aTopic, aData) {
        if (aProviderID != PARTNER_PACK_COMPID || aServiceName != PARTNER_PACK_SVCNAME)
            return;
        
        switch (aTopic) {
            case "registered":
                this._brandingService = aData;
                break;
            
            case "package updated":
                this._brandingData = null;
                
                this.lockKeywordURLPrefs();
                
                this.api.logger.debug("Package updated");
                break;
            
            default:
                break;
        }
    },
    
    _getUserChromeURI: function OmniBox__getUserChromeURI() {
        const IO_SERVICE = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
        
        let chromeCSSFile = this.api.Files.getWidgetStorage(true);
        chromeCSSFile.append("userChrome.css");
        
        if (chromeCSSFile.exists())
            return IO_SERVICE.newFileURI(chromeCSSFile);
        
        let fontsDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("Fnts", Ci.nsIFile);
        
        if (!(fontsDir.exists() && fontsDir.isDirectory()))
            return;
        
        let arialFile = fontsDir.clone();
        arialFile.append("arial.ttf");
        
        let arialbdFile = fontsDir.clone();
        arialbdFile.append("arialbd.ttf");
        
        if (!(arialFile.exists() && arialFile.isFile() &&
              arialbdFile.exists() && arialbdFile.isFile()))
            return;
        
        let arialFileSpec = IO_SERVICE.newFileURI(arialFile).spec;
        let arialbdFileSpec = IO_SERVICE.newFileURI(arialbdFile).spec;
        
        let fChannel = this.api.Package.getFileInputChannel("/native/fx/omnibox/userChrome.css");
        let fContent = this.api.StrUtils.readStringFromStream(fChannel.contentStream);
        
        fContent = fContent.replace(/%arial-path%/g, arialFileSpec)
                           .replace(/%arialbd-path%/g, arialbdFileSpec);
        
        this.api.Files.writeTextFile(chromeCSSFile, fContent);
        
        return IO_SERVICE.newFileURI(chromeCSSFile);
    },
    
    _manageUserChromeCSS: function OmniBox__manageUserChromeCSS(aEnable) {
        if (this.api.Environment.os.name != "windows")
            return;
        
        let userChromeCSSFileURI;
        try {
            userChromeCSSFileURI = this._getUserChromeURI();
        } catch (e) {}
        
        if (!userChromeCSSFileURI)
            return;
        
        const SS_SERVICE = Cc["@mozilla.org/content/style-sheet-service;1"].getService(Ci.nsIStyleSheetService);
        const USER_SHEET = SS_SERVICE.USER_SHEET;
        
        if (aEnable && !SS_SERVICE.sheetRegistered(userChromeCSSFileURI, USER_SHEET)) {
            try {
                SS_SERVICE.loadAndRegisterSheet(userChromeCSSFileURI, USER_SHEET);
            } catch (e) {
                this.api.logger.error("Can not register " + userChromeCSSFileURI.spec);
                this.api.logger.debug(e);
            }
        } else if (!aEnable && SS_SERVICE.sheetRegistered(userChromeCSSFileURI, SS_SERVICE.USER_SHEET)) {
            try {
                SS_SERVICE.unregisterSheet(userChromeCSSFileURI, USER_SHEET);
            } catch (e) {
                this.api.logger.error("Can not unregister " + userChromeCSSFileURI.spec);
                this.api.logger.debug(e);
            }
        }
    },
    
    get isGreaterThanFx36() {
        delete this.isGreaterThanFx36;
        return this.isGreaterThanFx36 = this.api.Environment.browser.version.isGreaterThan("3.7");
    },
    
    /* ********************************** *
     * Данные брендирования
     * ********************************** */
    _brandingData: null,
    get brandingData() {
        if (this._brandingData === null) {
            let brandId = this._brandingService.getBrandID();
            try {
                this.api.Package.getFileInputChannel("/branding/" + brandId + "/omnibox.xml");
            } catch (e) {
                brandId = "yandex";
            }
            
            const IOService = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
            let uri = IOService.newURI(this.api.Package.resolvePath("/branding/" + brandId + "/omnibox.xml"), null, null);
            let channel = IOService.newChannelFromURI(uri);
            let stream = channel.open();
            let xmlDoc = this.api.XMLUtils.xmlDocFromStream(stream, uri, uri, false);
            let omniboxElement = xmlDoc.querySelector("Omnibox");
            
            let brandingService = this._brandingService;
            let getTextContent = function _getTextContent(aQuerySelector) {
                let element = omniboxElement.querySelector(aQuerySelector);
                return brandingService.expandBrandTemplatesEscape(element.textContent);
            }
            
            let brandingData = {
                suggestionsURL: getTextContent("Suggestions > Url"),
                searchURL: getTextContent("Search > Url"),
                searchLabel: getTextContent("Search > Label")
            };
            
            this._brandingData = brandingData;
        }
        
        return this._brandingData;
    },
    
    get _textToSubURIService() {
        delete this._textToSubURIService;
        return this._textToSubURIService = Cc["@mozilla.org/intl/texttosuburi;1"].getService(Ci.nsITextToSubURI);
    },
    
    _convertQueryForURI: function SearchWidget__convertQueryForURI(aData, aQueryCharset) {
        let data = "";
        try {
            data = this._textToSubURIService.ConvertAndEscape(aQueryCharset, aData);
        } catch (ex) {
            data = this._textToSubURIService.ConvertAndEscape(DEFAULT_QUERY_CHARSET, aData);
        }
        
        return data;
    },
    
    makeSearchURLForString: function SearchWidget__makeSearchURLForString(aSearchTerms) {
        return this.brandingData.searchURL + this._convertQueryForURI(aSearchTerms, "UTF-8");
    },
    
    // Устанавливаем нужный нам адрес для поиска из адресной строки
    // как дефолтную настройку и лочим её. Браузер игнорирует
    // пользовательские значения таких настроек.
    lockKeywordURLPrefs: function OmniBox_lockKeywordURLPrefs() {
        let defaultBranch = Cc["@mozilla.org/preferences-service;1"]
                                .getService(Ci.nsIPrefService)
                                .getDefaultBranch("");
        
        defaultBranch.setCharPref("keyword.URL", this.brandingData.searchURL);
        defaultBranch.setBoolPref("keyword.enabled", true);
        
        let prefsModule = this.api.Settings.PrefsModule;
        prefsModule.lock("keyword.URL");
        prefsModule.lock("keyword.enabled");
    },
    
    unlockKeywordURLPrefs: function OmniBox_unlockKeywordURLPrefs() {
        let prefsModule = this.api.Settings.PrefsModule;
        if (prefsModule.locked("keyword.URL"))
            prefsModule.unlock("keyword.URL");
        if (prefsModule.locked("keyword.enabled"))
            prefsModule.unlock("keyword.enabled");
    },
    
    getWelcomePageURL: function OmniBox_getWelcomePageURL() {
        return this.api.Package.resolvePath("welcome/ff.html");
    },

    _showWelcomePageOnStart: function OmniBox__showWelcomePageOnStart() {
        this._showWelcomePageOnStart = function(){};
        
        let that = this;
        let timer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
        timer.initWithCallback({
            notify: function() that._openWelcomePage()
        }, 0, Ci.nsITimer.TYPE_ONE_SHOT);
    },
    
    _openWelcomePage: function OmniBox__openWelcomePage() {
        let firstStartBranch = this.api.Settings.getStaticBranchPath();
        firstStartBranch += "firststart";
        
        let firstStart = this.api.Settings.PrefsModule.get(firstStartBranch, null);
        if (firstStart)
            return;
        
        this.api.Settings.PrefsModule.set(firstStartBranch, true);
        
        if (this._isEmbedded())
            return;
        
        this.api.Controls.navigateBrowser({
            url: this.getWelcomePageURL(),
            target: "new tab"
        });
    },
    
    _isEmbedded: function OmniBox__isEmbedded() {
        try {
            return !!this.api.Package.getFileInputChannel("/embedded");
        } catch (e) {}
        
        return false;
    }
};

function OmniBoxUBItem(itemElement, itemClass, module) {
    this.itemElement = itemElement;
    itemElement.module = module;
    itemElement.setAttribute("yb-native-widget-name", WIDGET_ID);
};

OmniBoxUBItem.prototype = {
    itemElement: null,
    
    finalize: function OmniBoxUBItem_finalize() {
        this.itemElement.wdgtxDestructor();
        this.itemElement.module = null;
        this.itemElement = null;
    }
};
