"use strict";

const EXPORTED_SYMBOLS = ["OmniBox"];

const {
    classes: Cc,
    interfaces: Ci,
    results: Cr,
    utils: Cu
} = Components;

    
const OMNIBOX_SEARCH_PROTOCOL_NAME = "yaOmniBox";
const MAX_COMPLETE_RESULTS = 10;


/* ****************************************************** *
 * OmniBox
 * ****************************************************** */
Cu.import("resource://gre/modules/XPCOMUtils.jsm");

let OmniBox = {
    SEARCH_PROTOCOL_NAME: OMNIBOX_SEARCH_PROTOCOL_NAME,
    
    init: function OmniBox_init(core) {
        this.core = core;
        
        this._registerComponent();
        
        let api = core.api;
        
        Cu.import(api.Package.resolvePath("/native/fx/omnibox/corrector/inputCorrector.js"), this)
            .InputCorrector.init(core);
        
        Cu.import(api.Package.resolvePath("/native/fx/omnibox/urlengine.js"), this)
            .URLEngine.init(api);
        
        Cu.import(api.Package.resolvePath("/native/fx/omnibox/providersManager.js"), this)
            .ProvidersManager.init(core);
        
        this.MONO_DOMAINS_COUNT = this.api.Settings.PrefsModule.get("smartbox.behavior.mono_domains_count");
        if (this.MONO_DOMAINS_COUNT == null) {
            this.api.Settings.PrefsModule.set("smartbox.behavior.mono_domains_count", 2);
            this.MONO_DOMAINS_COUNT = 2;
        }
    },
    
    finalize: function OmniBox_finalize() {
        this.InputCorrector.finalize();
        this.InputCorrector = null;
        
        this.ProvidersManager.finalize();
        this.ProvidersManager = null;
        
        this.URLEngine.finalize();
        this.URLEngine = null;
        
        this._unregisterComponent();
        
        this.core = null;
    },
    
    get api() {
        return this.core.api;
    },
    
    get _isComponentRegistered() {
        return Components.manager
                         .QueryInterface(Ci.nsIComponentRegistrar)
                         .isCIDRegistered(OmniBoxAutoCompleteSearch.classID);
    },
    
    _registerComponent: function OmniBox__registerComponent() {
        if (this._isComponentRegistered)
            return;
        
        let s = OmniBoxAutoCompleteSearch;
        
        Components.manager.QueryInterface(Ci.nsIComponentRegistrar).registerFactory(
            s.classID,
            s.classDescription,
            s.contractID,
            s
        );
    },
    
    _unregisterComponent: function OmniBox__unregisterComponent() {
        if (!this._isComponentRegistered)
            return;
        
        Components.manager.QueryInterface(Ci.nsIComponentRegistrar).unregisterFactory(
            OmniBoxAutoCompleteSearch.classID,
            OmniBoxAutoCompleteSearch
        );
    },
    
    getSwitchedLayout: function OmniBox_getSwitchedLayout(aString) {
        return this.InputCorrector.getSwitchedLayout(aString);
    }
};

let OmniBoxAutoCompleteSearch = {
    classDescription: "YaOmnibox Auto-Complete Search Javascript XPCOM Component",
    classID:          Components.ID("9c44c220-9dda-11e0-82a2-5f3c55e510b7"),
    contractID:       "@mozilla.org/autocomplete/search;1?name=" + OMNIBOX_SEARCH_PROTOCOL_NAME,

    QueryInterface: XPCOMUtils.generateQI([Ci.nsIAutoCompleteSearch]),
    
    createInstance: function(aOuter, aIID) this.QueryInterface(aIID),
    
    startSearch: function OmniBoxAutoCompleteSearch_startSearch(aSearchString, aSearchParam, aPreviousResult, aListener) {
        this.stopSearch();
        
        OmniBox.api.logger.debug("Start search for '" + aSearchString + "' string.");
        aSearchString = aSearchString.toLowerCase();
        if (/^moz-action:/.test(aSearchString)) {
            let [,param] = aSearchString.match(/^moz\-action:yaaction\-[^,]+,[^\s]+\s(.*)$/)
                        || aSearchString.match(/^moz\-action:[^,]+,([^,]+),.*$/);
            OmniBox.api.logger.debug("Switch search string from '" + aSearchString + "' to '" + param + "'.");
            aSearchString = param || "";
        }
        
        this._searchString = aSearchString;
        this._searchListener = aListener;
        
        this._searchStartTime = Date.now();
        
        /*if (/^(https?|ftp):\/\/$/.test(trimmedString)) {
            ...?
        }*/
        /*let trimmedString = aSearchString.trim();
        if (!trimmedString) {
            this._notifySearchListener(Ci.nsIAutoCompleteResult.RESULT_NOMATCH, []);
            return;
        }*/
        
        let searchingStrings = [aSearchString];
        let switched = OmniBox.getSwitchedLayout(aSearchString);
        if (switched && aSearchString != switched) {
            searchingStrings.push(switched);
            this._searchStringSwitched = switched;
        }
            
        OmniBox.ProvidersManager.startSearch(searchingStrings, this);
    },
   
    stopSearch: function OmniBoxAutoCompleteSearch_stopSearch() {
        OmniBox.ProvidersManager.stopSearch();
        this._searchListener = null;
        this._searchString = null;
        this._searchStringSwitched = null;
        this._searchStartTime = null;
    },
    
    // Вспомогательная фукнция для отладки, выводит массив в консоль.
    _printArray: function OmniBoxAutoCompleteSearch__printArray(aName, aArray) {
        if (OmniBox.api.logger.level > 20) // current level > DEBUG
            return;
        let info = [[i.value, i.style, i.comment].join(" === ") for each (i in aArray)];
        OmniBox.api.logger.debug("Data in '" + aName + "':\n" + info.join("\n"));
    },
    
    // Перемещает из массива from элементы к массиву to, 
    // в случае если to не имеет добавляемых урлов, 
    // возвращает:
    // { result - to с добавленными элементами
    //  source - from без добавленных и без прочих совпадающих элементов
    //  changed - флаг показывающий были ли добавлены какие то элементы
    _uniqueMove: function OmniBoxAutoCompleteSearch__uniqueMove(to, from, count) {
        let itemsCount = (count == null) ? from.length : count
        let j = 0;
        let i = 0;
        let added = false;
        for (i = 0; i < from.length; i++) {
            let [notUnique, count] = OmniBox.URLEngine.hasURL(to, from[i].value);
            if (notUnique || count >= OmniBox.MONO_DOMAINS_COUNT)
                continue;
            j++;
            to.push(from[i]);
            added = true;
            if (j == itemsCount)
                break;
        }
        return { result: to, source : from, changed : added};
    },
    
    _onSearchResult: function OmniBoxAutoCompleteSearch__onSearchResult(aSearchResults) {
        OmniBox.api.logger.debug("Search time: " + (Date.now() - this._searchStartTime) + " ms.");
        
        let bookmarks = [];                 // Закладки в браузере
        let history = [];                   // История браузинга
        let switchToTab = [];               // Текущие открытые вкладки браузера
        let onlineSuperNavigationSuggestions = [];   // Поисковые подсказки online c признаком nav
        let onlineSearchSuggestions = [];   // Поисковые подсказки online
        let onlineNavigateSuggestions = []; // Навигационные подсказки online
        let onlineHistorySuggestions = [];  // Поисковые подсказки из моей истории поисков online от Яндекса
        let offlineSearchHistory = [];      // Поисковые подсказки из моей истории поисков offline от Бара
        let unknown = [];                   // Результаты неизвестного нам типа.
        
        presortingResults:
        for (let i = 0; i < aSearchResults.length; i++) {
            let result = aSearchResults[i];
            
            let url = result.value;
            
            let resultsToPush = unknown;
            // "action favicon" => ["action favicon", "action", "favicon"]
            // TODO: Сортировка по приоритетности.
            /* Альтернативный вариант:
               Проход по всем частям стиля (["action", "favicon"]) с последующим
               добавлением в тот массив, вес которого окажется наивысшим.
            */
            let styles = [result.style].concat(result.style.split(" "));
            
            for (let i = 0, len = styles.length; i < len; i++) {
                let style = styles[i];
                
                switch (style) {
                    case "action":
                        if (url.indexOf("moz-action:switchtab") == 0) {
                            // Из результатов убираем переключение на текущий таб.
                            // Более логично это было бы делать в биндинге в окне браузера,
                            // но есть некоторые сложности с удалением/скрытием richlistitem
                            // из сформированного списка.
                            let winMediator = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
                            let topBrowserWindow = winMediator.getMostRecentWindow("navigator:browser");
                            let browser = topBrowserWindow && topBrowserWindow.gBrowser;
                            let currentURL = browser.currentURI && browser.currentURI.spec;
                            if (currentURL && url.indexOf("," + currentURL) != -1)
                                continue presortingResults;
                            
                            resultsToPush = switchToTab;
                        }
                        break;
                    
                    case "yaNavigationSuggest":
                        resultsToPush = onlineNavigateSuggestions;
                        break;
                        
                    case "yaSuperNavigationSuggest":
                        resultsToPush = onlineSuperNavigationSuggestions;
                        break; 
                        
                    case "yaSearchSuggest":
                        resultsToPush = onlineSearchSuggestions;
                        break;
                    
                    case "yaOfflineSearchHistory":
                        resultsToPush = offlineSearchHistory;
                        break;
                    
                    case "keyword":
                    case "bookmark":
                    case "tag":
                        resultsToPush = bookmarks;
                        break;
                    
                    case "favicon":
                        resultsToPush = history;
                        break;
                }
                
                if (resultsToPush !== unknown)
                    break;
            }
            
            if (resultsToPush === unknown)
                OmniBox.api.logger.debug("unknown style: " + styles + "\n");
            
            resultsToPush.push(result);
        }
        
        if (OmniBox.api.logger.level < 20) {
            let infoText = [];
            let infoData = [
                ["bookmarks", bookmarks],
                ["history", history],
                ["switchToTab", switchToTab],
                ["onlineSearchSuggestions", onlineSearchSuggestions],
                ["onlineSuperNavigationSuggestions", onlineSuperNavigationSuggestions],
                ["onlineNavigateSuggestions", onlineNavigateSuggestions],
                ["onlineHistorySuggestions", onlineHistorySuggestions],
                ["offlineSearchHistory", offlineSearchHistory],
                ["unknown", unknown]
            ];
            
            infoData.forEach(function(arr) {
                let [name, results] = arr;
                if (results.length) {
                    infoText.push(name + " (" + results.length + ")\n  "
                                + [("value: " + res.value + ", style: " + res.style)
                                   for each (res in results)].join("\n  "));
                }
            });
            
            OmniBox.api.logger.debug("OmniBoxAutoCompleteSearch__onSearchResult\n"
                                   + "Results for '" + this._searchString + "'\n"
                                   + infoText.join("\n"));
        }
        
        this._printArray("hist", history);
        
        let allResults = [];
        let navigationGroup = [];
        let searchingGroup = [];
        //let combinedHistory = history.concat(bookmarks)
        let matchedIndex = OmniBox.URLEngine.isMatchedArray(history, this._searchString, this._searchStringSwitched, true);

        let [type,] = OmniBox.URLEngine.getInputType(this._searchString);
        let [stype,] = OmniBox.URLEngine.getInputType(this._searchStringSwitched);

        let isURL = type == "url" || stype == "url";
                
    		if (matchedIndex == -1 && onlineSuperNavigationSuggestions.length == 0 || (isURL && matchedIndex == -1) ) 
    			   matchedIndex = OmniBox.URLEngine.isMatchedArray(onlineNavigateSuggestions, this._searchString, this._searchStringSwitched, true);
        
        let autocompleteSearchSuggest = (matchedIndex == -1);
        if (matchedIndex != -1 || isURL) { 
            OmniBox.api.logger.debug(["case:", 1, this._searchString])
            // Если урл совпадает где то с историей, то совпадающую ссылку показываем первой
            if (matchedIndex != -1 && history.length) {
                let historyItem = history.splice(matchedIndex, 1);
                history.splice(0, 0, historyItem[0]);
            }
            let switchers = [];
            
            let  obj = this._uniqueMove(switchers, history, 1);
            switchers = obj.result;
            history = obj.source;
            
            if (!obj.changed) {
                obj = this._uniqueMove(switchers, onlineNavigateSuggestions, 1);
                switchers = obj.result;
                onlineNavigateSuggestions = obj.source;
            }
            
            if (switchers.length == 0 && this._searchString.trim() != "") {
              //Cu.reportError([type, stype])
                let url = "";
                if (type == "url")
                    url = this._searchString;
                else if (stype == "url")
                  url = this._searchStringSwitched;
                  
                switchers.push({    /// навигация, на урл
                    value: url,
                    comment: "",
                    image: null,
                    style: "yaNavigationSuggest"
                });
                autocompleteSearchSuggest = false;
            }
            //     Общий
            
            if (offlineSearchHistory.length)
                searchingGroup.push(offlineSearchHistory.shift());
            if (onlineHistorySuggestions.length)
                searchingGroup.push(onlineHistorySuggestions.shift());
            if (onlineSearchSuggestions.length)
                searchingGroup = searchingGroup.concat(onlineSearchSuggestions);
            
            if (searchingGroup.length) {
                obj = this._uniqueMove(switchers, searchingGroup, 1);
                switchers = obj.result;
                searchingGroup = obj.source;
            } else if ( this._searchString.trim() != "")
                searchingGroup.push({    /// найти в поиске
                    value: this._searchString,
                    comment: "",
                    image: null,
                    style: "yaSearchSuggest yaFirstSearchSuggest"
                });
            
            obj = this._uniqueMove(switchers, switchToTab, 1);
            switchers = obj.result;
            switchToTab = obj.source;
            
            // /Общий TODO: подумать как вынести этот код так как он встречается в каждом кейсе, но на разных входящих данных
                
            if (bookmarks.length)
                navigationGroup.push(bookmarks.shift());
        
            if (onlineNavigateSuggestions.length)
                navigationGroup.push(onlineNavigateSuggestions.shift());
        
            if (history.length)
                navigationGroup = navigationGroup.concat(history);

            if (onlineNavigateSuggestions.length)
                navigationGroup = navigationGroup.concat(onlineNavigateSuggestions);

            // добиваем группу если остались подсказки
            if (bookmarks.length)
                navigationGroup = navigationGroup.concat(bookmarks);
            
            
            allResults = switchers;

            obj = this._uniqueMove(allResults, navigationGroup, Math.min(4, navigationGroup.length));
            allResults = obj.result;
            navigationGroup = obj.source;
            
            obj = this._uniqueMove(allResults, searchingGroup, Math.min(4, searchingGroup.length));
            allResults = obj.result;
            searchingGroup = obj.source;
            
            // Случай когда пользователь нажал на кнопку дропдауна у адресной строки, добиваем строки из истории
            if (this._searchString.trim() == "") {
                obj = this._uniqueMove(allResults, navigationGroup, Math.min(10 - allResults.length, navigationGroup.length));
                allResults = obj.result;
                navigationGroup = obj.source;
            }

            /// TODO: Сделать дополнения хвоста если не хватило подсказок в группах
        } else if (onlineSuperNavigationSuggestions.length) { //2. Не выполнено условие для варианта 1 и ввод пользователя имеет супер навигационную онлайн подсказку
            OmniBox.api.logger.debug(["case:", 2, this._searchString]);
            
            // Переключатели
            let switchers = [];
            // Навигационная онлайн подсказка
            let  obj = this._uniqueMove(switchers, onlineSuperNavigationSuggestions, 1);
            switchers = obj.result;
            onlineSuperNavigationSuggestions = obj.source;
            
            //     Общий

            if (offlineSearchHistory.length)
                searchingGroup.push(offlineSearchHistory.shift());
            if (onlineHistorySuggestions.length)
                searchingGroup.push(onlineHistorySuggestions.shift());
            if (onlineSearchSuggestions.length)
                searchingGroup = searchingGroup.concat(onlineSearchSuggestions);
            if (searchingGroup.length == 0 && this._searchString.trim() != "")
                searchingGroup.push({    /// найти в поиске
                    value: this._searchString,
                    comment: "",
                    image: null,
                    style: "yaSearchSuggest yaFirstSearchSuggest"
                });
            // Первая подсказка из поисковой группы подсказок
            obj = this._uniqueMove(switchers, searchingGroup, 1);
            switchers = obj.result;
            searchingGroup = obj.source;
            /// Переключатель на открытый таб
            obj = this._uniqueMove(switchers, switchToTab, 1);
            switchers = obj.result;
            switchToTab = obj.source;
            
            allResults = switchers;
            // /Общий
            // Поисковые подсказки
            obj = this._uniqueMove(allResults, searchingGroup, Math.min(4, searchingGroup.length));
            allResults = obj.result;
            searchingGroup = obj.source;
            
            if (bookmarks.length)
                navigationGroup.push(bookmarks.shift());
        
            if (onlineNavigateSuggestions.length)
                navigationGroup.push(onlineNavigateSuggestions.shift());
        
            if (history.length)
                navigationGroup = navigationGroup.concat(history);

            if (onlineNavigateSuggestions.length)
                navigationGroup = navigationGroup.concat(onlineNavigateSuggestions);
            // добиваем группу если остались подсказки
            if (bookmarks.length)
                navigationGroup = navigationGroup.concat(bookmarks);

            // Навигационные подсказки 
            obj = this._uniqueMove(allResults, navigationGroup, Math.min(4, navigationGroup.length));
            allResults = obj.result;
            navigationGroup = obj.source;
            
        } else {
            OmniBox.api.logger.debug(["case:", 3, this._searchString])
            // Переключатели
            let switchers = [];
            //     Общий
            if (offlineSearchHistory.length)
                searchingGroup.push(offlineSearchHistory.shift());
            if (onlineHistorySuggestions.length)
                searchingGroup.push(onlineHistorySuggestions.shift());
            if (onlineSearchSuggestions.length)
                searchingGroup = searchingGroup.concat(onlineSearchSuggestions);
            if (searchingGroup.length == 0 && this._searchString.trim() != "") {
                searchingGroup.push({    /// найти в поиске
                    value: this._searchString,
                    comment: "",
                    image: null,
                    style: "yaSearchSuggest yaFirstSearchSuggest"
                });
            }
            
            // Первая подсказка из поисковой группы подсказок
            let obj = this._uniqueMove(switchers, searchingGroup, 1);
            switchers = obj.result;
            searchingGroup = obj.source;
            
            if (bookmarks.length)
                navigationGroup.push(bookmarks.shift());
        
            if (onlineNavigateSuggestions.length)
                navigationGroup.push(onlineNavigateSuggestions.shift());
        
            if (history.length)
                navigationGroup = navigationGroup.concat(history);

            if (onlineNavigateSuggestions.length)
                navigationGroup = navigationGroup.concat(onlineNavigateSuggestions);
            
            // добиваем группу если остались подсказки
            if (bookmarks.length)
                navigationGroup = navigationGroup.concat(bookmarks);

            // Первая подсказка из навигационной группы подсказок
            obj = this._uniqueMove(switchers, navigationGroup, 1);
            switchers = obj.result;
            navigationGroup = obj.source;
            
            /// Переключатель на открытый таб
            obj = this._uniqueMove(switchers, switchToTab, 1);
            switchers = obj.result;
            switchToTab = obj.source;
            
            allResults = switchers;
            // Поисковые подсказки
            obj = this._uniqueMove(allResults, searchingGroup, Math.min(4, searchingGroup.length));
            allResults = obj.result;
            searchingGroup = obj.source;

            // Навигационные подсказки 
            
            obj = this._uniqueMove(allResults, navigationGroup, Math.min(4, navigationGroup.length));
            allResults = obj.result;
            navigationGroup = obj.source;
            

        }

        
        // Если вообще ничего нет, тогда  
        if (allResults.length == 0 && this._searchString.trim() != "") {
            allResults.push({    /// найти в поиске
                value: this._searchString,
                comment: "",
                image: null,
                style: "yaSearchSuggest yaFirstSearchSuggest"
            });
        }
        
        if (allResults.length == 1 && allResults[0].style == "yaSearchSuggest") {
            let slashed = this._searchString.substr(-1) == "/";
            let [type,] = OmniBox.URLEngine.getInputType(this._searchString);
            if (type == "url") {
                allResults.push({    /// навигация, на урл
                    value: this._searchString + (slashed ?  "" : "/"),
                    comment: "",
                    image: null,
                    style: "yaNavigationSuggest"
                });
            }
            if (slashed && allResults.length == 2) {
                let searchElement = allResults.shift();
                allResults.push(searchElement);
            }
        }
        if (allResults.length == 1 && allResults[0].style == "yaNavigationSuggest") {
            allResults.push({    /// навигация, на урл
                value: this._searchString,
                comment: "",
                image: null,
                style: "yaSearchSuggest yaFirstSearchSuggest"
            });
        }
        
        let resultStatus = Ci.nsIAutoCompleteResult.RESULT_NOMATCH;
        if (this._providersQueue)
            resultStatus = Ci.nsIAutoCompleteResult.RESULT_SUCCESS_ONGOING;
        else if (allResults.length)
            resultStatus = Ci.nsIAutoCompleteResult.RESULT_SUCCESS;
        
        // Установка экшенов-ссылок для навигационных и поисковых саггестов.
        allResults.forEach(function(elem) {
            if (elem.action)
                return;
            
            let [,,type] = elem.style.match(/(^|\s)(yaNavigationSuggest|yaOfflineSearchHistory|yaSearchSuggest)(\s|$)/) || [];
            if (!type)
                return;
            
            let url;
            let actionType;
            
            switch (type) {
                case "yaNavigationSuggest":
                    let [, _url] = OmniBox.URLEngine.getInputType(elem.value);
                    url = _url || elem.value;
                    break;
                
                case "yaOfflineSearchHistory":
                case "yaSearchSuggest":
                    actionType = "opensearch";
                    url = OmniBox.core.makeSearchURLForString(elem.value);
                    break;
            }
            
            if (!url)
                return;
            
            elem.action = {
                type: actionType || "openurl",
                value: url
            };
        }, this);
        
        /*
        if (OmniBox.api.logger.level < 20) {
            OmniBox.api.logger.debug("OmniBoxAutoCompleteSearch__onSearchResult\n"
                                   + "Final results (" + allResults.length + ") for '" + this._searchString + "'\n"
                                   + [("value: " + res.value + ", style: " + res.style)
                                      for each (res in allResults)].join("\n"));
        }
        */
        
        this._notifySearchListener(resultStatus, allResults, autocompleteSearchSuggest);
    },
    
    get OmniBoxSearchAutoCompleteResult() {
        delete this.OmniBoxSearchAutoCompleteResult;
        Cu.import(OmniBox.api.Package.resolvePath("/native/fx/omnibox/autoComplResTempl.js"), this);
        return this.OmniBoxSearchAutoCompleteResult;
    },
    
    _notifySearchListener: function OmniBoxAutoCompleteSearch__notifySearchListener(aResultStatus, aResults, autocompleteSearchSuggest) {
        let completeDefaultIndex = -1;
        if ((aResults.length && !autocompleteSearchSuggest
            && /(^|\s)(yaDefaultComplete|yaNavigationSuggest|keyword|bookmark|tag|favicon)($|\s)/.test(aResults[0].style)) ||
            /(^|\s)(yaSuperNavigationSuggest)($|\s)/.test(aResults[0].style))
            completeDefaultIndex = 0;
        
        let result = new this.OmniBoxSearchAutoCompleteResult(this._searchString, aResultStatus,
                                                              aResults, aResults.length, completeDefaultIndex, "");
        this._searchListener.onSearchResult(this, result);
        
        OmniBox.api.logger.debug("Search time (total): " + (Date.now() - this._searchStartTime) + " ms.");
    }
};
