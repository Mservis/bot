"use strict";

const EXPORTED_SYMBOLS = ["DataProvider"];

const {
    classes: Cc,
    interfaces: Ci,
    results: Cr,
    utils: Cu
} = Components;

let DataProvider = {
    SEARCH_PARAM: null,

    PROVIDER_NAME: "offline-form-history-suggest",
    DATA_SERVICE: "yaOmniBoxSuggestDataService",
    
    get _formHistory() {
        delete this._formHistory;
        return this._formHistory = Cc["@mozilla.org/autocomplete/search;1?name=form-history"]
                                       .createInstance(Ci.nsIAutoCompleteSearch);
    },
    
    init: function FormHistoryDataProvider_init(core) {
        this.api = core.api;
        this.SEARCH_PARAM = this.api.Autocomplete.commonHistoryCategory;

        this._providerService = this.api.Services.obtainService(this.api.componentID, this.DATA_SERVICE , this);
        if (!this._providerService)
            return;
        if (!this._providerService.registerDataProvider(this))
            return;
    },
    
    isAsync: false,
    
    observeServiceEvent: function FormHistoryDataProvider_observeServiceEvent(aProviderID, aServiceName, aTopic, aData) {
        if (this.DATA_SERVICE != aServiceName || this.api.componentID != aProviderID)
            return;
        
        switch (aTopic) {
            case "start-collecting":
                this._startSearch(aData);
                break;
            case "stop-collecting":
                this._stopSearch();
                break;
        }
    },
    
    _startSearch: function FormHistoryDataProvider_startSearch(aSearchStrings) {
        this._originalSearchStrings = aSearchStrings;
        
        this._searchingStrings = aSearchStrings.map(function(s) s.trim());
        if (this._searchingStrings.join("") === "")
            this._searchingStrings = [];
        
        this._suggestions = [];
        
        this._debugSearchStartTime = Date.now();
        this._searchNextString();
    },
    
    _searchNextString: function FormHistoryDataProvider__searchNextString() {
        if (!this._searchingStrings.length) {
            this.api.logger.trace("History (form) search time: " + (Date.now() - this._debugSearchStartTime) + " ms.");
            this._finishSearch(true);
            return;
        }
        
        let [searchString] = this._searchingStrings.splice(0, 1);
        
        let that = this;
        this._searchNextStringTimer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
        this._searchNextStringTimer.initWithCallback({
            notify: function() that._formHistory.startSearch(searchString, that.SEARCH_PARAM, null, that)
        }, 10, Ci.nsITimer.TYPE_ONE_SHOT);
    },
    
    _stopSearch: function FormHistoryDataProvider__stopSearch() {
        this._formHistory.stopSearch();
        this._finishSearch(false);
    },
    
    _finishSearch: function FormHistoryDataProvider__finishSearch(aNotify) {
        if (this._searchNextStringTimer) {
            this._searchNextStringTimer.cancel();
            delete this._searchNextStringTimer;
        }
        
        if (aNotify)
            this._notifyResults();
        
        delete this._originalSearchStrings;
        delete this._searchingStrings;
        delete this._suggestions;
    },
    
    _notifyResults: function FormHistoryDataProvider__notifyResults() {
        this._providerService.handleResponse("start-collecting", {
            originalSearchStrings: [this._originalSearchString],
            suggestions: this._suggestions
        }, this);
    },
    
    // nsIAutoCompleteObserver
    onSearchResult: function FormHistoryDataProvider_onSearchResult(aAutoCompleteSearch, aAutoCompleteResult) {
        // Если поиск продолжается, то ждём его завершения и следующего вызова onSearchResult.
        if (aAutoCompleteResult.searchResult == Ci.nsIAutoCompleteResult.RESULT_NOMATCH_ONGOING ||
            aAutoCompleteResult.searchResult == Ci.nsIAutoCompleteResult.RESULT_SUCCESS_ONGOING)
            return;
        
        let originalSearchString = aAutoCompleteResult.searchString;
        
        let suggestions = [];
        let i = -1;
        while (++i < aAutoCompleteResult.matchCount) {
            let value = aAutoCompleteResult.getValueAt(i);
            let index = value.indexOf(originalSearchString);
            if (index == -1)
                continue;
            
            if (index == 0 || value[index - 1] == " ") {
                suggestions.push({
                    value: value,
                    comment: aAutoCompleteResult.getCommentAt(i),
                    image: null,
                    style: "yaOfflineSearchHistory"
                });
            }
        }
        
        this._suggestions = this._suggestions.concat(suggestions);
        
        this._searchNextString();
    },
    
    // nsIAutoCompleteObserver
    onUpdateSearchResult: function FormHistoryDataProvider_onUpdateSearchResult(aAutoCompleteSearch, aAutoCompleteResult) {
    }
};
