"use strict";

const EXPORTED_SYMBOLS = ["Corrector"];

const {
    classes: Cc,
    interfaces: Ci,
    results: Cr,
    utils: Cu
} = Components;

const UConverter = Cc["@mozilla.org/intl/scriptableunicodeconverter"].createInstance(Ci.nsIScriptableUnicodeConverter);
UConverter.charset = "UTF-8";

const russianLayout = UConverter.ConvertToUnicode(
                         "йцукенгшщзхъфывапролджэячсмитьбюёЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮЁіІ");
const englishLayout = "qwertyuiop[]asdfghjkl;'zxcvbnm,.`QWERTYUIOP[]ASDFGHJKL;'ZXCVBNM,.`sS";

Cu.import("resource://gre/modules/XPCOMUtils.jsm");
Cu.import("resource://gre/modules/ctypes.jsm");

const Corrector = {
    init: function Corrector_init(api) {
        this.api = api;
    },
    
    finalize: function Corrector_finalize() {
    },
    
    getSwitchedLayout: function Corrector_getSwitchedLayout(aString) {
        let results = "";
        
        for each(let char in aString) {
            let engIndex = englishLayout.indexOf(char);
            let rusIndex = russianLayout.indexOf(char);
            if (engIndex != -1)
                results += russianLayout[engIndex];
            else if (rusIndex != -1)
                results += englishLayout[rusIndex];
            else
                results += char;
        }

        return results;
    }
};
