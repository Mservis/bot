"use strict";

const EXPORTED_SYMBOLS = ["ProvidersManager"];

const {
    classes: Cc,
    interfaces: Ci,
    results: Cr,
    utils: Cu
} = Components;

const VERSION = "1.0";

let SuggestDataService = {
    SERVICE_NAME: "yaOmniBoxSuggestDataService",
    
    getVersion: function SuggestDataService_getVerion() VERSION,
    
    registerDataProvider: function SuggestDataService_registerDataProvider(aProvider) {
        return ProvidersManager.registerDataProvider(aProvider);
    },
    
    handleResponse: function SuggestDataService_handleResponse(aTopic, aData, aProvider) {
        if (aTopic == "start-collecting")
            ProvidersManager.onSearchResult(aProvider, aData);
    },
    
    removeDataProvider: function SuggestDataService_removeDataProvider(aProvider) {
        ProvidersManager.removeDataProvider(aProvider);
    }
};

let ProvidersManager = {
    
    init: function ProvidersManager_init(core) {
        this.core = core;
        
        core.api.Services.registerService(SuggestDataService.SERVICE_NAME, SuggestDataService);
        
        this.loadDataProviders();
    },
    
    finalize: function ProvidersManager_finalize() {
        this.stopSearch();
        this._dataProviders = {__proto__: null};
        this.api.Services.unregisterService(SuggestDataService.SERVICE_NAME);
        this.core = null;
    },
    
    get api() {
        return this.core.api;
    },
    
    _dataProviders: {__proto__: null},
    
    startSearch: function ProvidersManager_startSearch(aSearchStrings, aListener) {
        this.stopSearch();
        
        this._searchListener = aListener;
        
        this._clearProvidersQueue();

        this.api.Services.notifyServiceUsers(SuggestDataService.SERVICE_NAME, "start-collecting", aSearchStrings);
    },

    stopSearch: function ProvidersManager_stopSearch() {
        this.api.Services.notifyServiceUsers(SuggestDataService.SERVICE_NAME, "stop-collecting");
        
        this._searchListener = null;
        this._searchString = null;
        this._searchStartTime = null;
    },
    
    _clearProvidersQueue: function ProvidersManager__clearProvidersQueue() {
        this._results = [];
        
        this._providersQueue = 0;
        
        for each (let provider in this._dataProviders) {
            //if (!provider.isAsync)
                this._providersQueue++;
        }
    },
    
    _markProviderInQueue: function ProvidersManager__markProviderInQueue(aProvider) {
        if ((aProvider.PROVIDER_NAME in this._dataProviders)/* && !aProvider.isAsync*/)
            this._providersQueue--;
    },
    
    onSearchResult: function ProvidersManager_onSearchResult(aDataProvider, aResult) {
        this._markProviderInQueue(aDataProvider);
        
        this._results = this._results.concat(aResult.suggestions);
        
        if (this._providersQueue == 0 /*|| продолжают работать только асинхронные провайдеры*/)
            this._searchListener._onSearchResult(this._results);
    },
    
    registerDataProvider: function ProvidersManager_registerDataProvider(aProvider) {
        if (this._dataProviders[aProvider.PROVIDER_NAME]) {
            return false;
        }
        
        this._dataProviders[aProvider.PROVIDER_NAME] = aProvider; 
        
        return true;
    },
    
    removeDataProvider: function ProvidersManager_removeDataProvider(aProvider) {
        if (this._dataProviders[aProvider.PROVIDER_NAME])
            delete this._dataProviders[aProvider.PROVIDER_NAME];
    },
    
    loadDataProviders: function ProvidersManager_loadDataProviders() {
        let providersPath = "/native/fx/omnibox/providers/";
        
        [ "places",
          "suggests",
          "formHistory"
        ].forEach(function(aProviderName) {
            Cu.import(this.api.Package.resolvePath(providersPath + aProviderName + ".js"), {})
                .DataProvider
                .init(this.core);
        }, this);
    }
};
