"use strict";

const EXPORTED_SYMBOLS = ["DataProvider"];

const {
    classes: Cc,
    interfaces: Ci,
    results: Cr,
    utils: Cu
} = Components;

Cu.import("resource://gre/modules/XPCOMUtils.jsm");

const HTTP_OK = 200;

function isArray(aValue) // Array.isArray(aValue) // fx4+
    aValue && Object.prototype.toString.call(aValue) == "[object Array]";

let DataProvider = {
    // Максимальное время ожидания ответа от сервера.
    SUGGEST_TIMEOUT: 500, // ms
      
    PROVIDER_NAME: "online-yandex-suggest",
    DATA_SERVICE: "yaOmniBoxSuggestDataService",
    
    init: function SuggestDataProvider_init(core) {
        this.suggestsURL = core.brandingData.suggestionsURL;
        
        this.api = core.api;
        
        Cu.import(this.api.Package.resolvePath("/native/fx/omnibox/urlengine.js"), this);
        this.URLEngine.init(this.api);

        this._providerService = this.api.Services.obtainService(this.api.componentID, this.DATA_SERVICE , this);
        if (!this._providerService)
            return;
        if (!this._providerService.registerDataProvider(this))
            return;
    },
    
    isAsync: false,
    
    observeServiceEvent: function SuggestDataProvider_observeServiceEvent(aProviderID, aServiceName, aTopic, aData) {
        if (this.DATA_SERVICE != aServiceName || this.api.componentID != aProviderID)
            return;
        
        switch (aTopic) {
            case "start-collecting":
                this._startSearch(aData);
                break;
            case "stop-collecting":
                this._stopSearch();
                break;
        }
    },
    
    _startSearch: function SuggestDataProvider__startSearch(aSearchStrings) {
        this._stopSearch();
        
        this._originalSearchString = aSearchStrings[0];
        this._suggestions = [];
        
        let trimmedSearchString = this._trimmedSearchString = aSearchStrings[0].trim();
        
        // Не ищем подсказки для "www", "www." и пустого ввода.
        if (!trimmedSearchString) {
            this._finishSearch(true);
            return;
        }
        
        this.convertToWwwStyle = trimmedSearchString.indexOf("www.") == 0;

        let url = this.suggestsURL + encodeURIComponent(trimmedSearchString);
        
        let req = Cc["@mozilla.org/xmlextras/xmlhttprequest;1"].createInstance(Ci.nsIXMLHttpRequest);
        req.open("GET", url, true);
        req.channel.notificationCallbacks = new SearchSuggestLoadListener();
        
        let self = this;
        
        // Если не получим ответа за приемлемое время (SUGGEST_TIMEOUT),
        // то прервём поиск и уведомим наблюдателя. В противном случае
        // показ всех результатов застрянет как минимум на время получения ответа.
        this._requestTimer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
        this._requestTimer.initWithCallback(function() self._finishSearch(true),
                                            this.SUGGEST_TIMEOUT,
                                            Ci.nsITimer.TYPE_ONE_SHOT);
        
        function onReadyStateChange() self._onReadyStateChange(trimmedSearchString);
        req.onreadystatechange = onReadyStateChange;
        req.send(this.SUGGEST_POSTDATA);
        
        this._request = req;
    },
    
    _stopSearch: function SuggestDataProvider_stopSearch() {
        // Запрос не прерываем. Возможно он ещё отработает и при следующем
        // поиске такой же фразы получим его из кэша браузера.
        //if (this._request) this._request.abort();
        
        this._finishSearch(false);
    },
    
    _finishSearch: function SuggestDataProvider__finishSearch(aNotify) {
        if (this._requestTimer) {
            this._requestTimer.cancel();
            this._requestTimer = null;
        }
        
        if (aNotify)
            this._notifyResults(false);
        
        delete this._originalSearchString;
        delete this._suggestions;
        delete this._request;
    },
    
    _notifyResults: function SuggestDataProvider__notifyResults() {
        this._providerService.handleResponse("start-collecting", {
            originalSearchStrings: [this._originalSearchString],
            suggestions: this._suggestions
        }, this);
    },
    
    _onReadyStateChange: function SuggestDataProvider__onReadyStateChange(aSearchString) {
        if (aSearchString !== this._trimmedSearchString) {
            return;
        }
        
        if (!this._request || this._request.readyState != 4)
            return;
        
        this._handleResponse();
        this._finishSearch(true);
    },
    
    _formatURL: function SuggestDataProvider__formatURL(url) {
        let truncatedURL = url.replace(/^https?:\/\//i, "");
        if (this.convertToWwwStyle && truncatedURL.indexOf("www.") != 0)
            return url.replace(truncatedURL, "") + "www." + truncatedURL;
      
        return url;
    },
    
    _handleResponse: function SuggestDataProvider__handleResponse(aSearchString) {
        if (!this._request)
            return;
        
        let status;
        try {
            status = this._request.status;
        } catch (e) {
            return;
        }
        
        // TODO: http://mxr.mozilla.org/mozilla-central/source/toolkit/components/search/nsSearchSuggestions.js#347
        /*if (this._isBackoffError(status)) {
            this._noteServerError();
            return;
        }*/
        
        let responseText = this._request.responseText;
        if (status != HTTP_OK || responseText == "")
            return;
        
        //this.api.logger.trace("SuggestDataProvider, response text:\n" + responseText);
        
        let suggestionResults = [];
        let navigationSuggest = [];

        try {
            let res = JSON.parse(responseText)[1];
            if (isArray(res))
                suggestionResults = res;
        } catch(e) {
            Cu.reportError(e);
        }
        
        try {
            let res = JSON.parse(responseText)[2];
            if (isArray(res))
                navigationSuggest = res;
        } catch(e) {
            Cu.reportError(e);
        }
        
        let suggestions = [];
        
        let navigationSuggestURL = navigationSuggest.length > 1 && this._getNavigationSuggestURL(navigationSuggest[1]);
        if (navigationSuggestURL) {
            suggestions.push({
                value: this._formatURL(navigationSuggest[1]),
                comment: navigationSuggest[0],
                image: "",
                style: "yaSuperNavigationSuggest",
                action: {
                    type: "openurl",
                    value: navigationSuggestURL
                }
            });
        }
        
        suggestionResults.forEach(function(res) {
            let url = this._getNavigationSuggestURL(res);
            
            let suggest = {
                value: url ? this._formatURL(res) : res,
                comment: "",
                image: "",
                style: url ? "yaNavigationSuggest" : "yaSearchSuggest"
            };
            
            if (url) {
                suggest.action = {
                    type: "openurl",
                    value: this._formatURL(url)
                };
            }
            
            suggestions.push(suggest);
        }, this);
        
        this._suggestions = suggestions;
        
        /*
        if (this.api.logger.level < 20) {
            this.api.logger.debug("Online suggestions for '" + this._originalSearchString + "':\n  "
                                + [("value: " + res.value + ", style: " + res.style)
                                   for each (res in suggestions)].join("\n  "));
        }
        */
    },
    
    _getNavigationSuggestURL: function SuggestDataProvider__getNavigationSuggestURL(aString) {
        let [type, url] = this.URLEngine.getInputType(aString, true);
        if (type == "url" && /^(https?|ftp):\/\//.test(url))
            return url;
        return null;
    }
};

function SearchSuggestLoadListener() {}

SearchSuggestLoadListener.prototype = {
  // nsIBadCertListener2
  notifyCertProblem: function SSLL_certProblem() true,

  // nsISSLErrorListener
  notifySSLError: function SSLL_SSLError() true,

  // nsIInterfaceRequestor
  getInterface: function SSLL_getInterface(iid) this.QueryInterface(iid),

  // nsISupports
  QueryInterface: XPCOMUtils.generateQI([Ci.nsIBadCertListener2,
                                         Ci.nsISSLErrorListener,
                                         Ci.nsIInterfaceRequestor])
};
