	function init() {
		// quit if this function has already been called
		if (arguments.callee.done) return;
		
		// flag this function so we don't do the same thing twice
		arguments.callee.done = true;
		
		// kill the timer
		if (_timer) {
			clearInterval(_timer);
			_timer = null;
		}
		
		// content
		var linkArr = getElementsByClassName('b-suggest-menu__link');
		var removeElem = '';
		
		for (i=0;i<linkArr.length;i++) {
			linkArr[i].onclick = function(){
				removeElem = getElementsByClassName('b-suggest-menu__item_selected')[0];
				for (j=0;j<linkArr.length;j++) {
					removeClass(removeElem,'b-suggest-menu__item_selected');
				};
				addClass(this.parentNode,'b-suggest-menu__item_selected');
				var rel=this.getAttribute('rel'),
					imgClass = 'b-suggest__img b-suggest__img_'+rel;
				document.getElementById('j-b-suggest-img').className = imgClass;
			};
		};
	};
	
	/* for Mozilla */
	if (document.addEventListener) {
		document.addEventListener("DOMContentLoaded", init, false);
	}
	
	/* for Internet Explorer */
	/*@cc_on @*/
	/*@if (@_win32)
		document.write("<script id=__ie_onload defer src=javascript:void(0)><\/script>");
		var script = document.getElementById("__ie_onload");
		script.onreadystatechange = function() {
			if (this.readyState == "complete") {
				init(); // call the onload handler
			}
		};
	/*@end @*/
	
	/* for Safari */
	if (/WebKit/i.test(navigator.userAgent)) { // sniff
		var _timer = setInterval(function() {
			if (/loaded|complete/.test(document.readyState)) {
				init(); // call the onload handler
			}
		}, 10);
	}
	
	window.onload = init;

	function getElementsByClassName(classname, node) { if (!node) { node = document.getElementsByTagName('body')[0]; } var a = [], re = new RegExp(classname); els = node.getElementsByTagName('*'); for (var i = 0, j = els.length; i < j; i++) { if ( re.test(els[i].className) ) { a.push(els[i]); } } return a; }
	
	function hasClass(ele,cls) {return ele.className.match(new RegExp(/\bb-suggest-menu__item_selected\b/));}
	function addClass(ele,cls) {if (!this.hasClass(ele,cls)) ele.className += ' '+cls;}
	function removeClass(ele,cls) {if (hasClass(ele,cls)) {var reg = new RegExp(/\bb-suggest-menu__item_selected\b/);ele.className=ele.className.replace(reg,'');}}