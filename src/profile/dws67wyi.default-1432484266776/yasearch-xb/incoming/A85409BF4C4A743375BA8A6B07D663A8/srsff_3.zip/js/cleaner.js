(function() {
    try {
		if (typeof __YaSggst == 'undefined') {
			return;
		}
			
		__YaSggst('input[magicYaSggst]').data('magicYaSggst').removeSuggest();
		__YaSggst('input[ya-srs-injected="true"]').removeAttr("magicYaSggst");
		__YaSggst('input[ya-srs-injected="true"]').removeAttr("autocomplete");
		__YaSggst('input[ya-srs-injected="true"]').removeAttr("ya-srs-injected");
		
        __YaSggst("link[href*=__YaSggst.ac.css]").remove();
        __YaSggst('#yandex-srs-container').remove();
		__YaSggst('#ya-autocomplete-srs').remove();
        __YaSggst('#suggest-variants').remove();
        __YaSggst('#yaFatalSitesuggestScript').remove();
        __YaSggst('input[duplicateYaInput=1]').remove();
        __YaSggst("script[src*=inject.js]").remove();

    } catch (e) { };
})(window);
