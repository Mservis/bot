const EXPORTED_SYMBOLS = ["core"];

const {
    classes: Cc,
    interfaces: Ci,
    results: Cr,
    utils: Cu
} = Components;



function SRSCore() {
    var $ = this;

    $.xbCore = {
        init: function xbCore_init(api) {
            this.api = api;
            $.init(api);
        },
        
        finalize: function xbCore_finalize() {
            $.finalize();
        },
        
        Settings: {
            getMainTemplate: function xbCore_getMainTemplate() {
                let fileChannel = $.api.Package.getFileInputChannel("preferences.xml");
                return fileChannel.contentStream;
            }
        },
        
        dropStore: function xbCore_dropStore(brunchName) {
          try {
            let storeBranch = $.api.Settings.getComponentBranchPath();
            storeBranch += "storeBrunch." + brunchName;
            let storeNumber = Number($.api.Settings.PrefsModule.get(storeBranch, 0));
            storeNumber++;
            $.api.Settings.PrefsModule.set(storeBranch, storeNumber);

            $._setPageContainersAttribute((brunchName == "history") ? "historyStorageNumber" : "visibilityStorageNumber", storeNumber);
            
          } catch(e) {
            Cu.reportError(e);
          }
        },
        
        getString: function xbCore_getString(name) {
            return $.getLocalizedString(name);
        }
    };
    
    $.init = function SRSCore_init(api) {
        $.api = api;
        $.start();
    };
    
    $._setPageContainersAttribute = function SRSCore__setPageContainerAttribute(attrName, attrValue) {
        let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
        let enumerator = wm.getEnumerator("navigator:browser");
        while (enumerator.hasMoreElements()) {
            let win = enumerator.getNext();
            let tabbrowser = win.gBrowser;
            let numTabs = tabbrowser.browsers.length;
            for (let index = 0; index < numTabs; index++) {
                let currentBrowser = tabbrowser.getBrowserAtIndex(index);
                let doc = currentBrowser.contentDocument;
                let container = doc.getElementById("yandex-srs-container");
                if (container == null)
                    continue;
                
                let event = doc.createEvent("Event");
                
                event.initEvent("ContainerModified", true, false);
                container.setAttribute(attrName, attrValue);
                container.dispatchEvent(event);
            }
        }
    };
    $._windowListener = {
        onOpenWindow: function(xulWindow) {
            let win = xulWindow.QueryInterface(Ci.nsIInterfaceRequestor)
                               .getInterface(Ci.nsIDOMWindowInternal);
            win.addEventListener("DOMContentLoaded", $._documentLoaded, true);
        },
        onWindowTitleChange: function(window, newTitle) {},
        onCloseWindow: function(window) {}    
    };
    $.injectCSS = function SRSCore_injectCSS(doc, path) {
        try {
            let ads_js = doc.createElement("style");
            ads_js.setAttribute("type", "text/css");
            let fileChannel = $.api.Package.getFileInputChannel(path);
            ads_js.innerHTML = $.api.StrUtils.readStringFromStream(fileChannel.contentStream);
            doc.getElementsByTagName("head")[0].appendChild( ads_js );
            return true;
        } catch(e) {$.log(e); return false;}
    };
    $.injectScript = function SRSCore_injectScript(doc, path, id) {
        try {
            let js = doc.createElement("script");
            js.setAttribute("type", "text/javascript");
            js.setAttribute("charset", "utf-8");
            let fileChannel = $.api.Package.getFileInputChannel(path);
            js.setAttribute("src", "data:text/javascript;," + encodeURIComponent($.api.StrUtils.readStringFromStream(fileChannel.contentStream)));
            js.setAttribute("id", id);
            doc.body.appendChild( js );
            return true;
        } catch(e) {$.log(e); return false;}
    };
    $._removeAllScripts = function SRSCore__removeAllScripts(document) {
        if (!$._isValidDocument(document))
            return;
    
        if (!$.injectScript(document, $.api.Package.resolvePath("js/cleaner.js"), "ya-cleaner-srs")) {
            $.log("Unable to inject script to doc");
            return;
        }
    };
    
    $.getLocalizedString = function SRSCore_getLocalizedStrings(name) {
        let bundle = Cc["@mozilla.org/intl/stringbundle;1"]
                         .getService(Ci.nsIStringBundleService)
                         .createBundle($.api.Package.resolvePath("string.properties"));
        
        return bundle.GetStringFromName(name);
        
    };
    
    $._setLocalizedStrings = function SRSCore__setLocalizedStrings(container) {
        let _bundle = Cc["@mozilla.org/intl/stringbundle;1"]
                          .getService(Ci.nsIStringBundleService)
                          .createBundle($.api.Package.resolvePath("string.properties"));

        let enumerator = _bundle.getSimpleEnumeration();
        while (enumerator.hasMoreElements()) {
            let property = enumerator.getNext().QueryInterface(Components.interfaces.nsIPropertyElement);

            container.setAttribute(property.key, property.value);
        }
        
        container.setAttribute("search", "Поиск");
    };
    $.tryInjectTo = function SRSCore_tryInjectTo(doc, input) {
        if (input.getAttribute("ya-srs-injected") == "true")
            return;
		
        let container = doc.getElementById("yandex-srs-container");
        if (container == null) {
            container = doc.createElement("div");
            container.setAttribute("id", "yandex-srs-container");
            $._setLocalizedStrings(container);

            let clid13 = 1122916;
            if ($.api.DistrData != null && $.api.DistrData.getRecord("clid13") != null)
                clid13 = $.api.DistrData.getRecord("clid13").clid;
            container.setAttribute("clid13", clid13);

            let storeBranch = $.api.Settings.getComponentBranchPath();
            storeBranch += "storeBrunch.history";
            container.setAttribute("historyStorageNumber", $.api.Settings.PrefsModule.get(storeBranch, 0));

            storeBranch = $.api.Settings.getComponentBranchPath();
            storeBranch += "storeBrunch.visibility";
            container.setAttribute("visibilityStorageNumber", $.api.Settings.PrefsModule.get(storeBranch, 0));
            
            doc.body.appendChild(container);
        }
        
        let ids = JSON.parse(container.getAttribute("ids"));
        
        if (ids == null)
            ids = [];

        ids.push(input.getAttribute("id"));

        container.setAttribute("ids", JSON.stringify(ids));
		
        if (doc.getElementById("ya-autocomplete-srs") != null)
            return;
        
        if (!$.injectCSS(doc, $.api.Package.resolvePath("js/__YaSggst.ac.css"))) {
            $.log("Unable to inject script to doc");
            return;
        }
		
        if (!$.injectCSS(doc, $.api.Package.resolvePath("js/lightBox_overlayff.css"))) {
            $.log("Unable to inject script to doc");
            return;
        }

		if (!$.injectScript(doc, $.api.Package.resolvePath("js/jquery-1.5.1.min.js"), "ya-srs-jquery")) {
            $.log("Unable to inject script to doc");
            return;
        }
        
        if (!$.injectScript(doc, $.api.Package.resolvePath("js/inject.js"), "ya-autocomplete-srs")) {
            $.log("Unable to inject script to doc");
            return;
        }

    };
    $._isValidDocument = function SRSCore__isValidDocument(doc) {
        if (!doc || !doc.body || (doc.defaultView.top !== doc.defaultView)) 
            return false;
         
        let matched =  doc.documentURI.match($._domainExpression);
        
        if (matched == null || matched[1] == "https://") 
            return false;
        
        if ($._blockedExpression != null && $._blockedExpression.test(matched[2].replace("www.", "")))
            return false;
        
        return true;
    };
    $._documentLoaded = function SRSCore__documentLoaded(event) {
        let doc = event.originalTarget;
		
        if (!$._isValidDocument(doc))
            return;
		
		doc.addEventListener("srs-bridge-element-event", function(e) {
			let bridgeElement = doc.getElementById("srs-bridge-element");
			if (!bridgeElement)
				return; 
			if (bridgeElement.getAttribute("srs-message") == "show-settings")
				$.api.Controls.openSettingsDialog(undefined, $.api.componentID);
		}, false, true); 
        
        $.startCollecting(doc);
    };
    
    $.getElementByName = function SRSCore_getElementByName(collection, name) {
        for (let i = 0; i < collection.length; i++) {
            if (collection[i].getAttribute("name") == name)
                return collection[i];
        }
        return null;
    };
    
	$._inputFocused = function SRSCore__inputFocused(e) {
		e.target.removeEventListener("focus", arguments.callee, false);
		$.tryInjectTo(e.target.ownerDocument, e.target);
	};
	
    $._attachToInput = function SRSCore__attachToInput(doc, input) {
        if ($._inputList == null)
			$._inputList = [];
		
        input.addEventListener("focus", $._inputFocused, false);
		$._inputList.push(input);
        
        if (doc.activeElement == input) {
          $.tryInjectTo(doc, input);
		}
    };
    
    $.startCollecting = function SRSCore_startCollecting(doc) {
        try {
			
            if ($._analyzer == null) {
                Cu.import($.api.Package.resolvePath("modules/analyzer.jsm"), $);
                let currentXmlDoc = $._getConfigXMLDocument();
                $._analyzer = new $.Analyzer(currentXmlDoc);
                Cu.import($.api.Package.resolvePath("modules/collector.jsm"), $);
            }
            
            if ($.DetectionObject == null)
                return;
            
            let detectedNames = $.DetectionObject($._analyzer, doc);
            for (let i = 0; i < detectedNames.length; i++) {
                let objectByName = $.getElementByName(doc.getElementsByTagName("input"), detectedNames[i]);
                let objectById = doc.getElementById(detectedNames[i]);
                if (objectByName != null)
                    $._attachToInput(doc, objectByName);
                if (objectById != null)
                    $._attachToInput(doc, objectById);
                    
            }
        } catch (e) {
            Cu.reportError(e);
        }
    }
    $._saveXMLToFile = function SRSCore__saveXMLToFile(xmldoc, file) {
        let serializer = Cc["@mozilla.org/xmlextras/xmlserializer;1"].createInstance(Ci.nsIDOMSerializer);
        let foStream = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
        foStream.init(file, 0x02 | 0x08 | 0x20, parseInt("0644", 8), 0);
        serializer.serializeToStream(xmldoc, foStream, "");
        foStream.close();
    };
    $._copyDefaultConfig = function SRSCore__copyDefaultConfig(file) {
        $.api.Files.writeStreamToFile($.api.Package.getFileInputChannel("data/config.xml").contentStream, file);
    };
    $._getConfigXMLDocument = function SRSCore__getConfigXMLDocument() {
        let configFile = $.api.Files.getWidgetStorage(true);
        configFile.append("config.xml");
        if (!configFile.exists())
            $._copyDefaultConfig(configFile);
        return $.api.XMLUtils.xmlDocFromFile(configFile);
    };
    $._tryDownloadUpdates = function SRSCore__tryDownloadUpdates() {

		let lastConfigModifiedBranch = $.api.Settings.getComponentBranchPath();
        lastConfigModifiedBranch += "lastConfigModified";
        let lastConfigModifiedTime = $.api.Settings.PrefsModule.get(lastConfigModifiedBranch, 0);
	
        let configFile = $.api.Files.getWidgetStorage(true);
        configFile.append("config.xml");
        if (!configFile.exists())
            $._copyDefaultConfig(configFile);

        let request = Cc["@mozilla.org/xmlextras/xmlhttprequest;1"].createInstance(Ci.nsIXMLHttpRequest);
        
        request.onload = function(aEvent) {   
			
			if (aEvent == null || aEvent.target == null)
				return;
				
            let newXMLdoc = aEvent.target.responseXML;
            if (newXMLdoc == null)
                return;
			
			let configElementList = newXMLdoc.getElementsByTagName("config");
            if (configElementList == null || configElementList.length == 0)
              return;
			  
            let configElement = configElementList[0];
            if (configElement == null)
              return;
            
			$.api.Settings.PrefsModule.set(lastConfigModifiedBranch, aEvent.target.getResponseHeader("Last-Modified"));
			
			let newVersion = configElement.getAttribute("ver");
         
			let currentXmlDoc = $._getConfigXMLDocument();
			let currentVersion = currentXmlDoc.getElementsByTagName("config")[0].getAttribute("ver");
			
            if (currentVersion < newVersion)
                $._saveXMLToFile(newXMLdoc, configFile);
        };
        
        request.open("GET", "http://export.yandex.ru/bar/config.xml", true);
        request.setRequestHeader("If-Modified-Since", new Date(lastConfigModifiedTime).toUTCString());
		
        request.send(null);
    };
    
    $._checkForUpdates = function SRSCore__checkForUpdates() {
        let lastUpdateBranch = $.api.Settings.getComponentBranchPath();
        lastUpdateBranch += "lastupdate";
        let currentTime = Date.now();
        let lastUpdateTime = Number($.api.Settings.PrefsModule.get(lastUpdateBranch, 0));
		
        if (!lastUpdateTime || Math.abs(lastUpdateTime - currentTime) > 7 * 24 * 60 * 60 * 1000) {
            $.api.Settings.PrefsModule.set(lastUpdateBranch, currentTime.toString());
            
            $._tryDownloadUpdates();
        }

    };
    
    $._initExpressions = function SRSCore__initExpressions() {
        try {
            $._domainExpression = new RegExp("^([a-zA-Z]{3,5}://)([-.a-zA-Z0-9\\u0080-\\uFFFF_]{2,255})(:\\d{1,5})?(|[/#?].*)$");
            let xmlDoc = $._getConfigXMLDocument();
            let domains = xmlDoc.getElementsByTagName("domain");
            let expression = "^(www\.)?(";
            for (let i = 0; i < domains.length; i++) {
                let domainNode = domains[i];
                if (i > 0)
                    expression += "|";
                let domainExpression = domainNode.childNodes[0].nodeValue;
                expression += domainExpression.replace(/\./g, "\\.").replace("*\\.", "(.*\.)?").replace("\\.*", "(\..*)?");
            }
            expression += ")$";
            $._blockedExpression = new RegExp(expression);
        } catch(e) { $.log(e); }
    };
    $.getWelcomePageURL = function SRSCore_getWelcomePageURL() {
        return $.api.Package.resolvePath("welcome/index.html");
    };
    
    $._showWelcomePage = function SRSCore__showWelcomePage() {
        let firstStartBranch = $.api.Settings.getStaticBranchPath();
        firstStartBranch += "firststart";
        
        let firstStart = $.api.Settings.PrefsModule.get(firstStartBranch, null);
        if (firstStart !== null)
            return;
        
        firstStart = "0";
        $.api.Settings.PrefsModule.set(firstStartBranch, firstStart);
        let firstStartBranchOld = $.api.Settings.getComponentBranchPath();
        firstStartBranchOld += "firststart";
        
        if ($.api.Settings.PrefsModule.get(firstStartBranchOld, null) !== null)
            return;
        
        $.api.Controls.navigateBrowser({
            url: $.getWelcomePageURL(),
            target: "new tab"
        });
        
        $.xbCore.dropStore();
    };
    
	$.isEmbedded = function SRSCore_isEmbedded() {
	    let file = __LOCATION__.parent;
	    file.append(".embedded");
	    return file.exists();
	}
	
    $.start = function SRSCore_start() {
        $._initExpressions();
        
        if (!$.isEmbedded())
            $._showWelcomePage();
        
        let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
        
        wm.addListener($._windowListener);
        let enumerator = wm.getEnumerator("navigator:browser");
        while (enumerator.hasMoreElements()) {
            let win = enumerator.getNext();
            win.addEventListener("DOMContentLoaded", $._documentLoaded, true);
            let tabbrowser = win.gBrowser;
            let numTabs = tabbrowser.browsers.length;
            for (let index = 0; index < numTabs; index++) {
                let currentBrowser = tabbrowser.getBrowserAtIndex(index);
                if (!$._isValidDocument(currentBrowser.contentDocument))
                    return;
                
                $.startCollecting(currentBrowser.contentDocument);
            }
        }
        let udateTimer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
        udateTimer.initWithCallback({
            notify: function(timer) { 
                $._checkForUpdates(); 
            } 
        }, 3000, Ci.nsITimer.TYPE_ONE_SHOT);
    };
    
    
    $.finalize = function SRSCore_finalize() {
        let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
        wm.removeListener($._windowListener);
        let enumerator = wm.getEnumerator("navigator:browser");
        while (enumerator.hasMoreElements()) {
            let win = enumerator.getNext();
            win.removeEventListener("DOMContentLoaded", $._documentLoaded, true);
            let tabbrowser = win.gBrowser;
            let numTabs = tabbrowser.browsers.length;
            for (let index = 0; index < numTabs; index++) {
                let currentBrowser = tabbrowser.getBrowserAtIndex(index);
                $._removeAllScripts(currentBrowser.contentDocument);
            }
        }
		
		if ($._inputList != null) {
		    for (let i = $._inputList.length; i-- > 0;) {
		        $._inputList[i].removeEventListener("focus", $._inputFocused, false);
		    }
		}
		
		$._inputList = null;
    };
}

SRSCore.prototype = {
    widget_name: "ru.yandex.bar.site-related-suggest",

    log: function (text) {
        this.api.logger.error(text);
    }, 
    
    toString: function() {
        return "[Application " + this.widget_name + "]";
    }
}

var srsCore = new SRSCore();
var core = srsCore.xbCore;
