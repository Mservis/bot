﻿var YandexNamespace = new function() {

    function YaSrsExtend(Child, Parent) {
        var F = function() { }
        F.prototype = Parent.prototype;
        Child.prototype = new F();
        Child.prototype.constructor = Child;
        Child.superclass = Parent.prototype;
    }

    function YaComponentBridge() {

        _bridgeElement = function() {
            if (!this.__bridgeElement) {
                this.__bridgeElement = document.createElement("SRSComponentBgidge");
                this.__bridgeElement.setAttribute("id", "srs-bridge-element");
                document.documentElement.appendChild(this.__bridgeElement);
            }
            return this.__bridgeElement;
        },

	    _sendIEMessage = function(message, data) {
	        var newEvt = document.createEventObject()
	        newEvt.setAttribute("srs-message", message);
	        newEvt.setAttribute("srs-data", data);
	        document.fireEvent("onpropertychange", newEvt)
	    },

	    _sendFFMessage = function(message, data) {
	        this._bridgeElement().setAttribute("srs-message", message);
	        this._bridgeElement().setAttribute("srs-data", data);

	        var e = document.createEvent("Events");
	        e.initEvent("srs-bridge-element-event", true, false);
	        this._bridgeElement().dispatchEvent(e);
	    },

        this.putMessage = function(message, data) {
            try {
                if (navigator.appVersion.indexOf("MSIE") == -1)
                    _sendFFMessage(message, data);
                else
                    _sendIEMessage(message, data);

            } catch (e) { alert(e.message) }
        }
    }

    function YaSRSStorage() {

        if (YaSRSStorage.superclass != null)
            YaSRSStorage.superclass.constructor.apply(this, arguments)

        var $ = this;
        var _maxVariantsInResult = 10;
        var _storageName = "ya-suggest-storage";

        var _getDate = function() {
            var oneDay = 1000 * 60 * 60 * 24;
            var checkDate = new Date('1/1/1970 0:00');
            var today = new Date();
            today = new Date((today.getMonth() + 1) + '/' + today.getDate() + '/' + today.getFullYear() + ' 0:00');
            return Math.floor((today - checkDate) / oneDay);
        };

        this.getLocaleString = function YandexStorage_getLocaleString(name) {
            var container = document.getElementById("yandex-srs-container");
            return container.getAttribute(name);
        };

        this.getLocaleStringAsArray = function YandexStorage_getLocaleString(name) {
            var string = this.getLocaleString(name);
            if (string == null)
                return null;
            var array = [];
            for (var i = 0; i < string.length; i++) {
                array.push(string.charCodeAt(i));
            }
            return array;
        };

        this.setKey = function YandexStorage_setKey(name, value, type) {
            type = (type == null) ? "visibility" : type;
            var sType = _storageName + "." + type;
            var storage = this._storage().getItem(sType);
            var storageObject = (storage != null) ? __YaSggst.parseJSON(storage) : {};
            storageObject[name] = value;
            this._storage().setItem(sType, __YaSggst.toJSON(storageObject));
        };

        this.getKey = function YandexStorage_getKey(name, type) {
            try {
                type = (type == null) ? "visibility" : type;
                var sType = _storageName + "." + type;
                var storage = this._storage().getItem(sType);
                var storageObject = (storage != null) ? __YaSggst.parseJSON(storage) : {};
                return storageObject[name];
            } catch (e) { return null; }
        };

        var _getValues = function() {
            try {
                var string = $.getKey("yandex-suggest-history", "history");
                var jsonObject = __YaSggst.parseJSON(string)
                return (jsonObject == null) ? [] : jsonObject;
            } catch (e) { return []; }
        };

        this.getSortedValues = function YandexStorage_getSortedValues(keys) {
            try {
                var store = _getValues();

                var list = [];
                if (!keys) {
                    list = store;
                } else if (store != null) {
                    for (var i = 0, len = store.length; i < len; i++) {
                        if (store[i].word.indexOf(keys) == 0)
                            list.push(store[i]);
                    }
                }

                list.sort(function(a, b) {
                    return (b.date - a.date) ||
                                                  ((b.date == a.date) && (b.count - a.count)) ||
                                                  ((b.date == a.date) && (b.count == a.count) && (b.time - a.time))
                });
                var result = [];
                if (list.length > _maxVariantsInResult)
                    list.length = _maxVariantsInResult;

                for (var i = 0, len = list.length; i < len; i++)
                    result.push(list[i].word);

                return result;
            } catch (e) { return []; }
        };

        this.putValue = function YandexStorage_putValue(value) {
            try {
                if (value == null || value == "")
                    return;
                var list = _getValues();

                var found = false;
                for (var i = 0; i < list.length; i++) {
                    var wordObject = list[i];
                    if (wordObject.word != value)
                        continue;

                    found = true;
                    wordObject.count = wordObject.count + 1;
                    wordObject.date = _getDate();
                    wordObject.time = (new Date()).getTime();
                    list[i] = wordObject;
                }

                if (found == false)
                    list.push({ "word": value, "count": 1, "date": _getDate(), "time": (new Date()).getTime() });

                this.setKey("yandex-suggest-history", __YaSggst.toJSON(list), "history");

            } catch (e) { }
        };

        this.setStorageNumber = function YandexStorage_setStorageNumber(number, type) {
            var currentNumber = $.getKey(_storageName + "-number", type);
            if (currentNumber == number)
                return;
            this._storage().setItem(_storageName + "." + type, "{}");
            this.setKey(_storageName + "-number", number, type);
        }
    }

    function YaStorageOperation() {
        this._storage = function() {
            return localStorage;
        };
    };

    function YaIE7StorageOperation() {

        this._createStorageElement = function() {
            var storageInput = document.createElement("input");
            storageInput.setAttribute("id", "ya-storage-element");
            storageInput.style.display = "none";
            storageInput.addBehavior("#default#userData");
            return document.body.appendChild(storageInput);
        },

        this._storage = function() {
            var StorageObject = {};
            StorageObject._storageElement = (document.getElementById("ya-storage-element") == null) ? this._createStorageElement() : document.getElementById("ya-storage-element");
            StorageObject.setItem = function(name, value) {
                this._storageElement.setAttribute(name, value);
                this._storageElement.save("ya-suggest-storage");
            };
            StorageObject.getItem = function(name) {
                this._storageElement.load("ya-suggest-storage");
                return this._storageElement.getAttribute(name);
            };

            return StorageObject;
        };

    };

    if (navigator.appVersion.indexOf("MSIE 7.0") != -1)
        YaSrsExtend(YaSRSStorage, YaIE7StorageOperation);
    else
        YaSrsExtend(YaSRSStorage, YaStorageOperation);


    this.YandexStorage = new YaSRSStorage();
    this.ComponentBridge = new YaComponentBridge();

};

(function($) {
    var m = {
        '\b': '\\b',
        '\t': '\\t',
        '\n': '\\n',
        '\f': '\\f',
        '\r': '\\r',
        '"': '\\"',
        '\\': '\\\\'
    },
        s = {
            'array': function(x) {
                var a = ['['], b, f, i, l = x.length, v;
                for (i = 0; i < l; i += 1) {
                    v = x[i];
                    f = s[typeof v];
                    if (f) {
                        v = f(v);
                        if (typeof v == 'string') {
                            if (b) {
                                a[a.length] = ',';
                            }
                            a[a.length] = v;
                            b = true;
                        }
                    }
                }
                a[a.length] = ']';
                return a.join('');
            },
            'boolean': function(x) {
                return String(x);
            },
            'null': function(x) {
                return "null";
            },
            'number': function(x) {
                return isFinite(x) ? String(x) : 'null';
            },
            'object': function(x) {
                if (x) {
                    if (x instanceof Array) {
                        return s.array(x);
                    }
                    var a = ['{'], b, f, i, v;
                    for (i in x) {
                        v = x[i];
                        f = s[typeof v];
                        if (f) {
                            v = f(v);
                            if (typeof v == 'string') {
                                if (b) {
                                    a[a.length] = ',';
                                }
                                a.push(s.string(i), ':', v);
                                b = true;
                            }
                        }
                    }
                    a[a.length] = '}';
                    return a.join('');
                }
                return 'null';
            },
            'string': function(x) {
                if (/["\\\x00-\x1f]/.test(x)) {
                    x = x.replace(/([\x00-\x1f\\"])/g, function(a, b) {
                        var c = m[b];
                        if (c) {
                            return c;
                        }
                        c = b.charCodeAt();
                        return '\\u00' +
                            Math.floor(c / 16).toString(16) +
                            (c % 16).toString(16);
                    });
                }
                return '"' + x + '"';
            }
        };

    $.toJSON = function(v) {
        var f = isNaN(v) ? s[typeof v] : s['number'];
        if (f) return f(v);
    };

    $.parseJSON = function(v, safe) {
        if (safe === undefined) safe = $.parseJSON.safe;
        if (safe && !/^("(\\.|[^"\\\n\r])*?"|[,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t])+?$/.test(v))
            return undefined;
        return eval('(' + v + ')');
    };

    $.parseJSON.safe = false;

})(__YaSggst);

/* __YaSggst */

(function($, storage) {
    YandexStorage = storage;
    var MIN_WIDTH = 100;
    $.Autocompleter = function($elem, options) {

        if (YandexStorage.getKey('closed') == '1')
            return;
        if ($elem.hasClass(options.inputClass))
            return;

        this.getMinWidth();
		

        if (window.$ && window.$.fn && window.$.fn.autocomplete) {
            window.$.fn.autocomplete = function() { };
            window.$($elem).unbind('keydown');
            this.isOtherSuggestFound = true;
        }

        this.param = ''; this.ul;
        this.selectClass_ = 'b____YaSggst-ac__item_selected';
        this.keyTimeout_ = null; this.lastKeyPressed_ = null; this.lastProcessedValue_ = null; this.lastSelectedValue_ = null;
        this.active_ = false; this.finishOnBlur_ = true;
        
        if (!$elem || !($elem instanceof __YaSggst) || $elem.length !== 1 || $elem.get(0).tagName.toUpperCase() !== 'INPUT') return;
        if (typeof options === 'string') { this.options = { url: options }; }
        else { this.options = options; }
        this.options.minChars = parseInt(this.options.minChars, 10);
        if (isNaN(this.options.minChars) || this.options.minChars < 0) { this.options.minChars = 1; }
        this.dom = {};

        this.initInputElement($elem);
		

        this.dom.$results = $('<div id="suggest-variants"></div>').hide();
        this.dom.$results.addClass(this.options.resultsClass);
        if (__YaSggst.browser.msie && parseInt(__YaSggst.browser.version) <= 7) {
            this.dom.$results.addClass(this.options.resultsClass + '-IE7');
        }


        this.dom.$results.css({ position: 'absolute' });

        __YaSggst('body').append(this.dom.$results);
        var self = this;

        this.dom.$elem.attr('onfocus', '');
        this.dom.$elem.attr('onblur', '');
        this.dom.$elem.attr('autocomplete', 'off');
        this.dom.$elem.attr('placeholder', '');
        this.dom.$bg_elem.attr('onfocus', '');
        this.dom.$bg_elem.attr('onblur', '');
        this.dom.$bg_elem.attr('placeholder', '');

        this.dom.$elem.keydown(function(e) {

            if (!self.isOtherSuggestFound) {
				if (document.body.addEventListener)
                    document.body.addEventListener('DOMNodeInserted', self.destroyOtherSgg, false);
                else if (document.body.attachEvent)
                    document.body.attachEvent('DOMNodeInserted', self.destroyOtherSgg);
				self.isOtherSuggestFound = true;
            }

            self.lastKeyPressed_ = e.keyCode;
            switch (self.lastKeyPressed_) {
                case 38:
                    e.preventDefault(); if (self.active_) self.focusPrev(); else self.activate();
                    setTimeout(function() {
                        self.updateBgText();
                    }, 1)

                    return false;
                    break;
                case 40:
                    e.preventDefault(); if (self.active_) self.focusNext(); else self.activate();
                    return false;
                    break;
                case 39:
                    self.onRightKeyPressed();
                    break;

                case 13:
                    if (self.active_) {
                        if (self.getCurrentItem() != null) {
                            e.preventDefault();
                            self.selectCurrent();
                            return false;
                        } else {
                            if (YandexStorage) {
                                YandexStorage.putValue(__YaSggst(e.target).val());
                            }

                            if (window.$) {
                                $elem.val(self.dom.$elem.val());
                                window.$($elem.parents('form')[0]).submit();
                                this.blur();
                            } else
                                __YaSggst($elem.parents('form')[0]).submit();

                            self.finish();
                        }
                    }

                    break;
                case 27:

                    if (self.active_) { e.preventDefault(); self.finish(); return false; }
                    break;
                case 9:
                    return false;
                default:
                    setTimeout(function() {
                        self.updateBgText();
                    }, 1)
                    self.activate();
                    break;
            }

            if ($.browser.msie) {
                setTimeout(function() {
                    self.lastSelection = self.dom.$elem.getSelection();
                }, 1);
            }
			
			if(window.$) {
				window.$(self.dom.$bg_elem[0]).trigger('keydown');
			}
        });
		
		if(window.$) {
			self.dom.$elem.keyup(function(){
				window.$(self.dom.$bg_elem[0]).trigger('keyup');
			});
			self.dom.$elem.keypress(function(){
				window.$(self.dom.$bg_elem[0]).trigger('keypress');
			});
		}
		
        this.dom.$elem.blur(function(e) {
			
            if (self.$focus_element === undefined)
                return;
			
            if (self.finishOnBlur_) {
                self.onBlurTimeout = setTimeout(function() {

                    self.finish();
                    self.$focus_element.removeClass('b____YaSggst-ac__input_focus');

                }, 200);
            } else {
                self.$focus_element.removeClass('b____YaSggst-ac__input_focus');
                self.dom.$bg_elem.val('');
                self.setCaret(self.dom.$elem.val().length);
            }
        });

        this.dom.$elem.focus(function() {
            if (self.$focus_element === undefined)
                self.$focus_element = self.getFocusedElement();

            self.$focus_element.addClass('b____YaSggst-ac__input_focus');
            setTimeout(function() {
                self.correctElementSize(self.dom.$bg_elem, self.dom.$elem);
            }, 1);

            self.activate();

        });
		
        $elem.focus(function() {
            self.setCaret(self.dom.$elem.val().length);
            self.dom.$elem.focus();
        });

        $elem.click(function() {
            self.setCaret(self.dom.$elem.val().length);
            self.activate();

        });


        if ($elem.get(0) === document.activeElement)
			self.dom.$elem.focus()

        $(window).resize(function() {
            if (self.active_)
                self.position();
        });
        
		$form = $elem.parents('form');
        if ($form.find('input[type="submit"]')) {
            $form.append('<input type="submit" style="display:none!important;"/>');
            $(function() {
                self.dom.$elem.focus()
            });

        }


    };


    var i18n = {
        show: YandexStorage.getLocaleStringAsArray("showSuggest"),
        hide: YandexStorage.getLocaleStringAsArray("hideSuggest"),
        remove_suggest: YandexStorage.getLocaleStringAsArray("removeSuggest"),
        title: YandexStorage.getLocaleStringAsArray("suggestTitle"),
        setup: YandexStorage.getLocaleStringAsArray("setup")
    };
    $.i18n = {};
    for (var k in i18n) {
        var cars = i18n[k],
          res = '',
          tlen = cars && cars.length;
        for (var i = 0; i < tlen; i++)
            res += String.fromCharCode(cars[i]);
        $.i18n[k] = res;
    }

    $.Autocompleter.prototype.getMinWidth = function() {
		this.measureMinWidth($.i18n.title, 20);
		this.measureMinWidth($.i18n.setup+" "+$.i18n.hide, 45);
        
    }
	
	$.Autocompleter.prototype.measureMinWidth = function(word, margins) {
		setTimeout(function() {
            var $div = $('<div style="position: absolute; overflow: hidden; width: 1px; height: 1px;"><div style="width: 2000px; position: absolute;" class="b____YaSggst-ac"><div class="b____YaSggst-ac-title"><span style="white-space: nowrap;">' + word + '</span></div></div></div>');
            $(document.body).append($div);
            var width = $div.find('span')[0].offsetWidth + margins;
			
			if(width > MIN_WIDTH)
				MIN_WIDTH = width;
            $div.remove();            
        });
	}

    $.Autocompleter.prototype.initInputElement = function($elem) {

        this.dom.$bg_elem = $elem;
        this.dom.$bg_elem.css('color', '#BBB')

        this.dom.$elem = this.duplicateInput($elem);
        this.dom.$elem.css({
            background: 'transparent',
            borderColor: 'transparent',
            color: '',
            zIndex: 100000
        });

        this.dom.$bg_elem.attr('name', '');
        if ($elem.parents('form').length == 0) {
            var form = this._findFormFor(this.dom.$bg_elem);
			if(form != null) { 
				var parent = form.parentNode;
				var pt = parent.tagName.toLowerCase();
				if (pt == 'tr' || pt == 'td' || pt == 'tbody') {
					do {
						parent = parent.parentNode;
					} while (parent.tagName.toLowerCase() != 'table');
				}
				parent.parentNode.insertBefore(form, parent);
				form.appendChild(parent);
			}
        }
    }
	
	$.Autocompleter.prototype._findFormFor = function($input) {
		$parent = $input.parent();
		for(var i=0; i<10; i++) {
			$form = $parent.find('form');
			if($form.length == 1)
				return $form[0];
		}
		return null;
	}



    $.Autocompleter.prototype.duplicateInput = function($elem) {
        $new = $elem.clone();
        $new.attr("duplicateYaInput", "1");
        $new.addClass(this.options.inputClass);
        $new.css({
            position: 'absolute'
        });
        $elem.before($new);
        $new.val($elem.val());
        this.correctElementSize($elem, $new);

        return $new;
    }

    $.Autocompleter.prototype.correctElementSize = function($elem, $new) {
        this.correctElementSize_coord($new, $elem.width(), 'width');
        this.correctElementSize_coord($new, $elem.height(), 'height');

        var dTop = $new.offset().top - $elem.offset().top;
        if (dTop != 0) {
            var oldTop = parseInt($new.css('margin-top'));
            if (isNaN(oldTop)) oldTop = 0;
            $new.css('margin-top', oldTop - dTop);
        }

        var dLeft = $new.offset().left - $elem.offset().left;
        if (dLeft != 0) {
            var oldLeft = parseInt($new.css('margin-left'));
            if (isNaN(oldLeft)) oldLeft = 0;
            $new.css('margin-left', oldLeft - dLeft);
        }
    }

    $.Autocompleter.prototype.correctElementSize_coord = function($elem, iw, coord) {
        var watchdog = 0;
        var cssw = iw;
        while ($elem[coord]() != iw) {
            $elem.css(coord, cssw);
            if ($elem[coord]() > iw)
                cssw--;
            else
                cssw++;
            if (++watchdog > 100)
                break;
        }
    }

    $.Autocompleter.prototype.position = function() {
        var offset = this.$focus_element.offset();
        var left = offset.left;
        var top = offset.top + this.$focus_element[0].offsetHeight;
        if ($.support.boxModel) left--;
        this.dom.$results.css({ top: top, left: left });
        if (__YaSggst.browser.msie) {
            if (__YaSggst.browser.version >= 9)
                this.dom.$results.addClass('b____YaSggst-ac_modie9');
        }
    };
    $.Autocompleter.prototype.activate = function() {
        var self = this;
        var activateNow = function() {
            self.activateNow();
        };
        var delay = 0;
        if (this.keyTimeout_) clearTimeout(this.keyTimeout_);
        this.keyTimeout_ = setTimeout(activateNow, delay);
    };
    $.Autocompleter.prototype.activateNow = function() {
        var value = this.dom.$elem.val().replace(/^\s+/,'').replace(/\s+$/,'');
        if (value !== this.lastProcessedValue_ && value !== this.lastSelectedValue_)
            if (value.length >= this.options.minChars) {
            this.active_ = true;
            this.lastProcessedValue_ = value;
            this.fetchData(value);
        }
    };
    $.Autocompleter.prototype.fetchData = function(value) {
        var self = this;
        this.fetchRemoteData(value, function(remoteData) { self.showResults(remoteData, value); });
    };
    $.Autocompleter.prototype.fetchRemoteData = function(filter, callback) {
        this.param = filter;
        var getDataFunction = this.options.getData;
        var parsed = this.parseRemoteData(getDataFunction(this.param));
        callback(parsed);
    };
    $.Autocompleter.prototype.parseRemoteData = function(remoteData) {
        var results = [], i, j, data, line, line_len = remoteData.length <= 5 ? remoteData.length : 5, line_len_2 = 0, value;
        this.prev_len = line_len;
        for (i = 0; i < line_len; i++)
            results.push(unescape(remoteData[i]).toLowerCase());
        return results;
    };
    $.Autocompleter.prototype.showResults = function(results, filter) {
        var self = this;
        var $ul = __YaSggst('<ul></ul>');
        $ul.addClass('b____YaSggst-ac__list');
        var i, result, $li, $first = false, numResults = results.length;
        self.ulLen = numResults;
        self.global = false;

        for (i = 0; i < numResults; i++) {
            result = results[i].replace(this.param, '<b>' + this.param + '</b>');
            self.global = true;
            $li = __YaSggst('<li class="b____YaSggst-ac__item b____YaSggst-ac__item_histotry"><div><i class="b____YaSggst-ac__item-text">' + result + '</i></div></li>');

            $li.data('value', result);
            $ul.append($li);
        }

        this.getDataFromSuggest($ul, results);
        this.updateResultWidth();
    };

    $.Autocompleter.prototype.updateResultWidth = function() {
        var extraWidth = this.$focus_element.outerWidth() - this.$focus_element.width();
        var w = this.$focus_element[0].offsetWidth;

        if (w > this.options.dth)
            w = this.options.maxWidth;
        if (w < MIN_WIDTH)
            w = MIN_WIDTH;

        this.dom.$results.width(w);
    }

    $.Autocompleter.prototype.showAdditionData = function(results, $ul, oldRes) {
        results = $.Autocompleter.prototype.clearExistingsResults(results, oldRes);

        var self = this;
        var i, $li, extraWidth, first = false, numResults = results.length, lFirst = false;
        if (self.ulLen <= 1)
            lFirst = true;

        if (numResults > 0) {
            self.ulLen += numResults;
            numResults = self.prev_len < 5 ? 10 - self.prev_len : 5;

            if (numResults > results.length)
                numResults = results.length;

            var text = (results[0]).toLowerCase().replace(this.param, '<b>' + this.param + '</b>');
            if (lFirst)
                $li = __YaSggst('<li class="b____YaSggst-ac__item b____YaSggst-ac__item_local b____YaSggst-ac__item_local_first b____YaSggst-ac__item_local_only"><div><i class="b____YaSggst-ac__item-text">' + text + '</i></div></li>');
            else
                $li = __YaSggst('<li class="b____YaSggst-ac__item b____YaSggst-ac__item_local b____YaSggst-ac__item_local_first"><div><i class="b____YaSggst-ac__item-text">' + text + '</i></div></li>');

            $li.data('value', results[0]);
            $ul.append($li);

            for (i = 1; i < numResults; i++) {
                result = results[i];
                $li = __YaSggst('<li class="b____YaSggst-ac__item b____YaSggst-ac__item_local"><div><i class="b____YaSggst-ac__item-text">' + result.toLowerCase().replace(this.param, '<b>' + this.param + '</b>') + '</i></div></li>');
                $li.data('value', result);
                $ul.append($li);
            }
        }

        if (this.param.length && $.inArray(this.param, results) == -1 && $.inArray(this.param, oldRes) == -1) {
            this.dom.$results.find('.b____YaSggst-ac__list .b____YaSggst-ac__item_empty').remove();
            value = "<b>" + this.param.toLowerCase() + "</b>";
            $li = __YaSggst('<li class="b____YaSggst-ac__item b____YaSggst-ac__item_local b____YaSggst-ac__item_empty"><div><i class="b____YaSggst-ac__item-text">' + value + '</i></div></li>');
            $li.data('value', value);
            $ul.append($li);
        }

        if ($ul.find('li').length == 0) {
            this.dom.$results.hide();
            return;
        }

        this.position();
        if (this.dom.$resultUl) {
            this.dom.$resultUl.html($ul.html());
            this.updateItemsMarginLeft();
            this.dom.$results.show();
            this.updateResultWidth();
            this.updateBgText();
            return;
        }
        this.dom.$results.append($ul).show();
        this.updateResultWidth();
        this.dom.$resultUl = this.dom.$results.find('ul');

        this.updateItemsMarginLeft();
        __YaSggst('<i class="b____YaSggst-ac-title">' + $.i18n.title + '</i>').insertBefore($ul);

        var _text = '', _advClass = '';
        if (YandexStorage.getKey('opened') != '0') {
            _text = $.i18n.hide;
        }
        else {
            _text = $.i18n.show;
        }

        var $t = ('<div class="b____YaSggst-ac-toggle"><i class="b____YaSggst-ac-toggle__setup"><b>'+$.i18n.setup+'</b></i><i class="b____YaSggst-ac-toggle__close" title="' + $.i18n.remove_suggest + '"></i><i class="b____YaSggst-ac-toggle__title' + _advClass + '"><b>' + _text + '</b></i></div>');
        this.dom.$resultUl.after($t);
        if (YandexStorage.getKey('opened') != '0')
            self.showHideSuggest(true, true);

        this.dom.$results.find('.b____YaSggst-ac-toggle__title,.b____YaSggst-ac-title').click(function() {
            setTimeout(function() {
                if (self.onBlurTimeout)
                    clearTimeout(self.onBlurTimeout);
                self.onBlurTimeout = null;

                self.dom.$elem[0].focus();
                if (self.lastSelection) {
                    self.dom.$elem.setSelection(self.lastSelection.start, self.lastSelection.end);
                    self.setCaret(self.dom.$elem.val().length);
                }
            }, 1);

            if ($(this).hasClass('b____YaSggst-ac-toggle__title')) {
                var isOpened = self.dom.$results.hasClass('b____YaSggst-ac_opened');
                self.showHideSuggest(!isOpened);
            }
        });
        this.dom.$results.find('.b____YaSggst-ac-toggle__close').click(function() {
            self.removeSuggest();
            YandexStorage.setKey('closed', '1');
        });

		this.dom.$results.find('.b____YaSggst-ac-toggle__setup').click(function() {
			YandexNamespace.ComponentBridge.putMessage("show-settings");
		});

	this.dom.$resultUl.mouseleave(function(){
			self.clearFocus();
		});

        var isMouseMoved = false;
        var lastMouseX, lastMouseY, mmTimeout;
        $(document.body).mousemove(function(e) {
            if (e.pageX != lastMouseX || e.pageY != lastMouseY) {
                lastMouseX = e.pageX;
                lastMouseY = e.pageY;
                isMouseMoved = true;
                clearTimeout(mmTimeout);
                mmTimeout = setTimeout(function() { isMouseMoved = false }, 500);
            }
        });
        this.dom.$resultUl.delegate('li', 'mouseenter', function() { if (isMouseMoved) { self.focusItem(this); } });
        this.dom.$resultUl.delegate('li', 'click', function() {
            self.selectItem($(this));
        })
        this.dom.$resultUl.delegate('li', 'mousedown', function() { self.finishOnBlur_ = false; })
        this.dom.$resultUl.delegate('li', 'mouseup', function() { self.finishOnBlur_ = true; });

        this.updateBgText();
        this.setCaret(this.dom.$elem.val().length);
    };

    $.Autocompleter.prototype.clearExistingsResults = function(results, oldRes) {
        if (!oldRes || !oldRes.length)
            return results;

        for (var i = 0; i < oldRes.length; i++) {
            var index = $.inArray(oldRes[i], results);
            if (index >= 0)
                results.splice(index, 1);
        }
        return results;
    };

    $.Autocompleter.prototype.updateBgText = function() {
        this.dom.$bg_elem.val(this.getBgText());
    }

    $.Autocompleter.prototype.getBgText = function() {
        $lis = this.dom.$results.find('li');
        if ($lis.length == 0)
            return '';

        var text = this.getItemText($lis.eq(0));
        var val = this.dom.$elem.val();
        if (text.length <= val.length)
            return '';
        if (val.length == '')
            return '';

        for (var i = 0; i < val.length; i++) {
            var v = val.substr(i, 1);
            var t = text.substr(i, 1);
            if (t != v) {
                if (t.toLowerCase() == v.toLowerCase())
                    text = text.substr(0, i) + v + text.substr(i + 1);
                else
                    return "";
            }
        }
        return text;
    }

    $.Autocompleter.prototype.removeSuggest = function() {
        var $bge = this.dom.$bg_elem;
        this.dom.$results.remove();
        $bge.attr('name', this.dom.$elem.attr('name'));
        var val = this.dom.$elem.val();

        setTimeout(function() {
            $bge.val(val);
        }, 100);

        $bge.css('color', getStyle(this.dom.$elem[0], 'color'));
        this.dom.$elem.remove();

        $bge.unbind('focus');
        $bge.unbind('click');

        if (document.body.removeEventListener)
            document.body.removeEventListener('DOMNodeInserted', this.destroyOtherSgg, false);
        else if (document.body.removeEventListener)
            document.body.removeEventListener('DOMNodeInserted', this.destroyOtherSgg, false);
    }

    $.Autocompleter.prototype.updateItemsMarginLeft = function() {
        var self = this;
        if (self.dom.$results.find('li').length > 0) {
            if (self._ieFixMargin === undefined) {
                setTimeout(function() {
                    var $lis = self.dom.$results.find('li');
                    var $lis_i = self.dom.$results.find('li div');
                    if ($lis[0].offsetWidth > 0 && self._ieFixMargin === undefined) {
                        self._ieFixMargin = self.dom.$resultUl[0].offsetWidth - $lis_i[0].offsetWidth - 10;
                        $lis.css('margin-left', -self._ieFixMargin);
                    }
                }, 10);
            } else
                self.dom.$results.find('li').css('margin-left', -self._ieFixMargin);
        }
    };
    $.Autocompleter.prototype.showHideSuggest = function(isShow, dontChangeText) {

        var self = this;
        if (!isShow) {
			/*
            self.dom.$results.removeClass('b____YaSggst-ac_opened');
            if (!dontChangeText)
                self.dom.$results.find('.b____YaSggst-ac-toggle__title b').html($.i18n.show);
            YandexStorage.setKey('opened', '0');
			*/
            self.removeSuggest();
            YandexStorage.setKey('closed', '1');

        }
        else {
            self.dom.$results.addClass('b____YaSggst-ac_opened');
            if (!dontChangeText) {
                self.dom.$results.find('.b____YaSggst-ac-toggle__title b').html($.i18n.hide);
                this.updateItemsMarginLeft();
            }
            YandexStorage.setKey('opened', '1');
        }

        self.setCaret(self.dom.$elem.val().length);
    };

    $.getDomain = function() {
        var domain = document.location.href.match("^([a-zA-Z]{3,5}://)([-.a-zA-Z0-9\\u0080-\\uFFFF_]{2,255})(:\\d{1,5})?(|[/#?].*)$")[2].replace("www.", "");
        if (domain.indexOf("www.") == 0)
            domain = domain.substr(4, domain.length);
        return (domain == "search.rg.ru") ? "rg.ru" : domain;
    };

    $.Autocompleter.prototype.getDataFromSuggest = function($ul, oldRes) {
        var self = this;

        __YaSggstCatchResponse = function(resp) { self.showAdditionData(resp[1], $('<ul class="b____YaSggst-ac__list">' + $ul.html() + '</ul>')/*на $ul.clone() IE ругается*/, oldRes); }

        var fileref = document.createElement("script");
        fileref.setAttribute("type", "text/javascript");
        fileref.setAttribute("charset", "UTF-8");
        fileref.setAttribute("src", 'http://sitesuggest.yandex.ru/suggest-ya.cgi?v=2&site=' + $.getDomain() + '&callback=__YaSggstCatchResponse&part=' + encodeURIComponent(this.param));
        fileref.setAttribute("id", "#yaFatalSitesuggestScript");
        document.body.appendChild(fileref);

    };

    $.Autocompleter.prototype.focusNext = function() { this.focusMove(+1); };
    $.Autocompleter.prototype.focusPrev = function() { this.focusMove(-1); };
    $.Autocompleter.prototype.focusMove = function(modifier) {
        var i, $items = __YaSggst('li', this.dom.$results);
        modifier = parseInt(modifier, 10);
        for (var i = 0; i < $items.length; i++)
            if (__YaSggst($items[i]).hasClass(this.selectClass_)) { this.focusItem(i + modifier, true); return; }
        if (modifier > 0)
            this.focusItem(0, true);
    };

    $.Autocompleter.prototype.focusItem = function(item, isChangeValue) {
        var $item, $items = __YaSggst('li', this.dom.$results);
        $items.removeClass(this.selectClass_).removeClass(this.options.selectClass);
        if ($items.length) {
            if (typeof item === 'number') {
                item = parseInt(item, 10);
                if (item >= 0) {
                    if (item >= $items.length) item = $items.length - 1;
                    $item = __YaSggst($items[item]);
                }
            } else $item = __YaSggst(item);

            if ($item && $item.length) {
                $item.addClass(this.selectClass_).addClass(this.options.selectClass);
                if (isChangeValue)
                    this.dom.$elem.val(this.getItemText($item));
            } else {
                if (isChangeValue)
                    this.dom.$elem.val(this.param);
            }
            if (isChangeValue) {
                this.dom.$bg_elem.val('');
            }
            this.$selectedItem = $item;
        }
    };

    $.Autocompleter.prototype.clearFocus = function() {
    	var $items = __YaSggst('li', this.dom.$results);
    	$items.removeClass(this.selectClass_).removeClass(this.options.selectClass);	
    }

    $.Autocompleter.prototype.getItemText = function($item) {
        if (!$item.hasClass('b____YaSggst-ac__item_empty'))
            return $item.text();
        else
            return this.param;
    };

    $.Autocompleter.prototype.getCurrentItem = function() {
        var $item = __YaSggst('li.' + this.selectClass_, this.dom.$results);
        return $item.length > 0 ? $item : null;
    }

    $.Autocompleter.prototype.selectCurrent = function() {
        var $item = this.getCurrentItem();
        if ($item.length)
            this.selectItem($item);
        else {

            this.finish();
        }
    };
    $.Autocompleter.prototype.selectItem = function($li) {
        var value = this.getItemText($li);

        var displayValue = this.displayValue(value);
        this.lastSelectedValue_ = displayValue;
        this.dom.$elem.val(value);

        this.setCaret(displayValue.length);

        this.finish();

        if (YandexStorage)
            YandexStorage.putValue(value);
        try {
            if (this.options.showSERP) {
                this.options.showSERP(value);
                this.lastProcessedValue_ = null;
                this.lastSelectedValue_ = null;
            }
        } catch (e) {
        }
    };

    $.Autocompleter.prototype.displayValue = function(value) { return value.replace(/<\/?b>/gi, "") };
    $.Autocompleter.prototype.finish = function() { if (this.keyTimeout_) clearTimeout(this.keyTimeout_); this.dom.$results.hide(); this.lastKeyPressed_ = null; this.lastProcessedValue_ = null; this.active_ = false; };
    $.Autocompleter.prototype.selectRange = function(start, end) {
        var input = this.dom.$elem.get(0);
        if (input.setSelectionRange) {
            input.focus();
            input.setSelectionRange(start, end);
        } else if (input.createTextRange) {
            var range = input.createTextRange();
            range.collapse(true); range.moveEnd('character', end); range.moveStart('character', start); range.select();
        }
    };
    $.Autocompleter.prototype.setCaret = function(pos) { this.selectRange(pos, pos); };
    $.Autocompleter.prototype.destroyOtherSgg = function(e) {
        var _class = e.target.className;

		if(e.target.nodeType != 1)
			return;
		
        if ($(e.target).parents('.b____YaSggst-ac').length == 0 && e.target.tagName.toLowerCase() != 'iframe' && $(e.target).find('iframe').length == 0) {
            var o = e.target.parentNode;
            //__YaSggst(e.target).remove();

            while (o) {
                var parent = o.parentNode;

                if ($(o).find('input[type="text"]').length)
                    break;

                if (o.className) {
					var cls = o.className.toLowerCase();
					if(cls.indexOf('suggest') > -1 || cls.indexOf('tips') > -1) {
						o.style.display = 'none';
						// parent.removeChild(o);
					}
				} 
                   
                if (o.id) {
					var id = o.id.toLowerCase();
					if(id.indexOf('suggest') > -1 || id.indexOf('tips') > -1) {
						//parent.removeChild(o);
						o.style.display = 'none';
					}
				}
                o = parent;
            }
        }
    };

    $.Autocompleter.prototype.onRightKeyPressed = function() {
        if (!this.active_)
            return;

        var selection = this.dom.$elem.getSelection();
        if (selection.end < this.dom.$elem.val().length)
            return;

        if (this.$selectedItem && this.dom.$elem.val() == this.getItemText(this.$selectedItem)) {
            this.focusItem(-1);
        } else {
            $lis = this.dom.$results.find('li');
            if ($lis.length > 0) {
                this.dom.$elem.val(this.getItemText($lis.eq(0)));
                this.activate();
            }
        }
    }

    function getStyle(x, styleProp) {
        var ss = styleProp.split('-');
        for (var i = 1; i < ss.length; i++)
            ss[i] = ss[i].substr(0, 1).toUpperCase() + ss[i].substr(1);
        var cStyle = ss.join('');

        var res = '';

        if (x.style[cStyle] !== undefined && x.style[cStyle].length)
            res = x.style[cStyle];
        else if (x.getStyle)
            res = x.getStyle(styleProp);
        else if (x.currentStyle)
            res = x.currentStyle[styleProp] || x.currentStyle[cStyle];
        else if (window.getComputedStyle)
            res = document.defaultView.getComputedStyle(x, null).getPropertyValue(styleProp);

        if (res == undefined)
            res = '';
        if (!res && styleProp == 'background-color')
            res = 'transparent';
        return res;
    }


    $.Autocompleter.prototype.getFocusedElement = function($input) {
        var $elem = this.dom.$bg_elem;
        if (this.isHasNoBorder($elem)) {
            var bgcolor = getStyle($elem[0], 'background-color');
            var $parent = $elem.parent();
            while ($parent.length && $parent[0].tagName.toLowerCase() != 'body') {
                try {
                    if ($parent[0].offsetWidth - $elem[0].offsetWidth > 20)
                        break;

                    var bg = getStyle($parent[0], 'background-color');
                    if (bgcolor == 'transparent')
                        var isOk = bg != 'transparent';
                    else
                        var isOk = bg == bgcolor;

                    if (isOk) {
                        if (getStyle($parent.parent()[0], 'overflow') == 'hidden')
                            $parent.parent().css('overflow', '');

                        return $parent;
                    }
                } catch (e) { }
                $parent = $parent.parent();
            }
        }
        return $elem;
    }

    $.Autocompleter.prototype.isHasNoBorder = function($elem) {
        if (this.isHasNoBorderPart($elem, ''))
            return true;
        var parts = ['bottom-', 'top-', 'left-', 'right-'];
        var partsCount = 0;
        for (var i = 0; i < parts.length; i++) {
            if (this.isHasNoBorderPart($elem, parts[i]))
                partsCount++;
        }
        if (partsCount >= 3)
            return true;

        return false;
    }

    $.Autocompleter.prototype.isHasNoBorderPart = function($elem, part) {
        if (parseInt(getStyle($elem[0], 'border-' + part + 'width')) == 0)
            return true;
        if (getStyle($elem[0], 'border-' + part + 'style').substr(0, 4) == 'none')
            return true;
        return false;
    }
    $.fn.getSelection = function() {
        var e = this[0];
        return (
        /* mozilla / dom 3.0 */
            ('selectionStart' in e && function() {
                var l = e.selectionEnd - e.selectionStart;
                return {
                    start: e.selectionStart,
                    end: e.selectionEnd,
                    length: l,
                    text: e.value.substr(e.selectionStart, l)
                };
            })
        /* exploder */
            || (document.selection && function() {
                e.focus();

                var r = document.selection.createRange();
                if (r == null) {
                    return {
                        start: 0,
                        end: e.value.length,
                        length: 0
                    };
                }

                var re = e.createTextRange();
                var rc = re.duplicate();
                re.moveToBookmark(r.getBookmark());
                rc.setEndPoint('EndToStart', re);
                var rcLen = rc.text.length,
                    i,
                    rcLenOut = rcLen;
                for (i = 0; i < rcLen; i++) {
                    if (rc.text.charCodeAt(i) == 13) rcLenOut--;
                }
                var rLen = r.text.length,
                    rLenOut = rLen;
                for (i = 0; i < rLen; i++) {
                    if (r.text.charCodeAt(i) == 13) rLenOut--;
                }

                return {
                    start: rcLenOut,
                    end: rcLenOut + rLenOut,
                    length: rLenOut,
                    text: r.text
                };
            })

        /* browser not supported */
            || function() {
                return {
                    start: 0,
                    end: e.value.length,
                    length: 0
                };
            }

        )();
    };
    $.fn.setSelection = function(start, end) {
        var e = this[0];
        if (!e) {
            return $(this);
        } else if (e.setSelectionRange) { /* WebKit */
            e.focus(); e.setSelectionRange(start, end);
        } else if (e.createTextRange) { /* IE */
            var range = e.createTextRange();
            range.collapse(true);
            range.moveEnd('character', end);
            range.moveStart('character', start);
            range.select();
        } else if (e.selectionStart) { /* Others */
            e.selectionStart = start;
            e.selectionEnd = end;
        }

        return $(this);
    };


    $.fn.magicYaSggst = function(options) {
        if (typeof options === 'string') options = { url: options };
        var o = $.extend({}, $.fn.magicYaSggst.defaults, options);

        return this.each(function() {
            var $this = __YaSggst(this);
            var ac = new $.Autocompleter($this, o);
            $this.data('magicYaSggst', ac);
            $this.attr('magicYaSggst', '1');

        });
    };


    $.fn.magicYaSggst.defaults = { resultsClass: 'b____YaSggst-ac', inputClass: 'b____YaSggst-ac__input', selectClass: 'b____YaSggst-ac__item_selected', minChars: 0, maxItemsToShow: 10, maxWidth: 400 };

    $.hasAnotherSuggest = function(object) {

        var getByClassName = function(object) {
            var words = ['autocomplete', 'suggest'];
            for (var k = 0; k < words.length; k++) {
                if (object.className.indexOf(words[k]) >= 0) {
                    return true;
                }
            }
            return false;
        };

        var getByJQuery = function() {
            return !!(window.$ && window.$.fn && window.$.fn.autocomplete);
        }

        var getByOtherAttributes = function(object) {
            var words = ['autocomplete', 'suggest'];
            for (var a = 0; a < object.attributes.length; a++) {
                var attr = object.attributes[a];
                if (attr.name != 'autocomplete' && attr.name != 'data-yandex-suggest') {
                    for (var k = 0; k < words.length; k++) {
                        if (attr.name.indexOf(words[k]) >= 0) {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        var byClass = getByClassName(object);
        var byAttrs = getByOtherAttributes(object);

        return (byClass /*|| byJQuery */ || byAttrs);
    };

})(__YaSggst, window.YandexNamespace.YandexStorage);


(function() {
    var $ = this;
    yandex_ac_off = false;

    yandex_indexInArray = function(array, element) {
        if (array.indexOf)
            return array.indexOf(array, element);
        else {
            for (var i = 0; i < array.length; i++) {
                if (array[i] == element)
                    return i;
            }
            return -1;
        }

    }

    _onFormSubmit = function(form) {
        var inputs = form.getElementsByTagName("input");
        for (var i = 0; i < inputs.length; i++) {
            var input = inputs[i];

            if (__YaSggst(input).hasClass("b____YaSggst-ac__input") == false || input.getAttribute("ya-srs-injected") != "true")
                continue;

            var value = input.value;
            YandexStorage.putValue(value);
        }
    };

    _clickEvent = function(e) {
        var element = (e.srcElement == null) ? e.target : e.srcElement;
        var form = _getParentForm(element);
        _onFormSubmit(form);
    }

    _wrapEvents = function(object, selector) {
        try {
            var objects = __YaSggst(object).find(selector).get();
            for (var i = 0; i < objects.length; i++) {
                var element = objects[i];
                if (element.attachEvent != null)
                    element.attachEvent("onclick", _clickEvent);
                if (element.addEventListener != null)
                    element.addEventListener("click", function(e) { _clickEvent(e); }, false);
            }
        } catch (e) { }
    }

    _catchToSubmitEvents = function(object) {
        _wrapEvents(object, ":image");
        _wrapEvents(object, ":submit");
    }

    _getParentForm = function(object) {
        while (object != null && object.tagName != null && object.tagName.toLowerCase() != "form")
            object = object.parentNode;
        return object;
    }

    _attachToParentForm = function(object) {
        object = _getParentForm(object);
        if (object.getAttribute == null || object.getAttribute("ya-srs-injected") != null)
            return;
        object.setAttribute("ya-srs-injected", "true");
        _catchToSubmitEvents(object);
    }

    _hasYandexSuggest = function(object) {
        var parent = object.parentNode;
        var suggests = __YaSggst(parent).children(".b-suggest").get()
        var hasSuggest = false;
        for (var i = 0; i < suggests.length; i++) {
            var suggest = suggests[i];
            if (suggest != null && suggest.tagName.toLowerCase() == "div") {
                var click = suggest.getAttribute("onclick");
                if (click != null && click.indexOf("sitesuggest.yandex.ru") != -1)
                    return true;
            }
        }
        return false;
    }


    _showSearchLightbox = function(value) {
        var headStyle = document.getElementsByTagName('html')[0].style.cssText;
        var bodyStyle = document.getElementsByTagName('body')[0].style.cssText;
        var url = 'http://' + YandexStorage.getLocaleString("searchDomain") + '/yandsearch?text=' + encodeURIComponent(value) + '&site=' + __YaSggst.getDomain() + '&clid=' + YandexStorage.getLocaleString("clid13") + '&lock_site=1';

        var boxDiv = document.getElementById("lightboxContainer");
        var liteboxFrame = document.getElementById("liteboxframe");
        var spin = document.getElementById("ru-yandex-bar-overlay-spin-trobber");

        if (boxDiv == null) {
            var head = document.getElementsByTagName('head')[0]
            var body = document.getElementsByTagName('body')[0]

            var boxDiv = document.createElement('div')
            boxDiv.className = 'ru-yandex-bar-overlay'
            boxDiv.setAttribute("id", "lightboxContainer");
            body.appendChild(boxDiv)

            var content = document.createElement('div')
            content.className = 'ru-yandex-bar-overlay-content'
            boxDiv.appendChild(content)

            var close = document.createElement('a')
            close.className = 'ru-yandex-bar-overlay-close'
            close.href = 'javascript://'
            content.appendChild(close)
            close.innerHTML = YandexStorage.getLocaleString("closeBox");

            liteboxFrame = document.createElement('iframe')
            liteboxFrame.setAttribute("id", "liteboxframe");
            liteboxFrame.frameBorder = 0
            liteboxFrame.src = url;
            liteboxFrame.className = 'ru-yandex-bar-overlay-frame'
            liteboxFrame.onload = liteboxFrame.onreadystatechange = function() {
                if (liteboxFrame.readyState == "loading")
                    return;
                if (liteboxFrame.readyState == "interactive")
                    return;

                spin.style.visibility = 'hidden';
                __YaSggst(liteboxFrame).focus();
            }
            content.appendChild(liteboxFrame)

            var spin = document.createElement('div')
            spin.setAttribute("id", "ru-yandex-bar-overlay-spin-trobber");
            spin.className = 'ru-yandex-bar-overlay-spin'
            content.appendChild(spin)
        }
        spin.style.visibility = 'visible';
        document.getElementsByTagName('html')[0].style.cssText =
			document.getElementsByTagName('body')[0].style.cssText =
			"height: 100% !important; padding: 0 !important; margin: 0 !important; min-height: 0 !important; min-width: 0 !important";
        boxDiv.style.display = "block";
        liteboxFrame.setAttribute("src", url);
        boxDiv.onclick = function(e) {
            boxDiv.style.display = "none";
            liteboxFrame.setAttribute("src", "about:blank");
            document.getElementsByTagName('html')[0].style.cssText = headStyle;
            document.getElementsByTagName('body')[0].style.cssText = bodyStyle;
        }
		__YaSggst(liteboxFrame).focus();
    };

    _attachToInput = function(object) {
        if (_hasYandexSuggest(object))
            return;
        if (object.getAttribute("autocomplete") == "off")
            return;
        if (__YaSggst.hasAnotherSuggest(object))
            return;
        object.setAttribute('autocomplete', 'off');
        object.setAttribute("ya-srs-injected", "true");
        _attachToParentForm(object);
		
        __YaSggst(object).magicYaSggst({
            getData: function(val) {

                return YandexStorage.getSortedValues(val);
            },
            showSERP: _showSearchLightbox
        });
    };

    attachToInputs = function(inputs_names) {
        for (var i = 0; i < inputs_names.length; i++) {
            var objectById = __YaSggst('#' + inputs_names[i]).get(0);
            if (objectById != null)
                _attachToInput(objectById);
        }
    };

    this.dettachFromAllInputs = function() {
        var container = document.getElementById("yandex-srs-container");
        var ids = __YaSggst.parseJSON(container.getAttribute("ids"))

        for (var i = 0; i < ids.length; i++) {
            __YaSggst('' + ids[i]).data("magicYaSggst").removeSuggest();
        }
    };


    _attachToAllFormElements = function(form) {
        var inputs = __YaSggst(form).find("input:not(:hidden)");
        for (var i = 0; i < inputs.length; i++) {
            var input = inputs.get(i);
            var yaDataEnabled = input.getAttribute("data-yandex-suggest");
            if (yaDataEnabled == "false")
                continue;
            _attachToInput(input);
        }
    }

    _TryAttachByUserRules = function() {
        var result = false;
        var forms = __YaSggst("form");
        for (var i = 0; i < forms.length; i++) {
            var form = forms.get(i);
            var yaDataEnabled = form.getAttribute("data-yandex-suggest");
            if (yaDataEnabled == null)
                continue;
            if (yaDataEnabled == "true")
                _attachToAllFormElements(form);
            result = true;
        }

        var inputsForAttach = __YaSggst("input:not(:hidden)[data-yandex-suggest='true']");
        for (var i = 0; i < inputsForAttach.length; i++) {
            var input = inputsForAttach.get(i);
            _attachToInput(input);
            result = true;
        }

        var hasAttr = __YaSggst("input:not(:hidden)[data-yandex-suggest='false']");
        if (result == false && hasAttr.length > 0)
            result = true;
        return result;
    }

    if (_TryAttachByUserRules())
        return;

    var container = document.getElementById("yandex-srs-container");
	function ContainerChanged(cnt) {
		YandexStorage.setStorageNumber(cnt.getAttribute("historyStorageNumber"), "history");
		YandexStorage.setStorageNumber(cnt.getAttribute("visibilityStorageNumber"), "visibility");
		attachToInputs(__YaSggst.parseJSON(cnt.getAttribute("ids")));
	}
	
    ContainerChanged(container);
	
    if (container.addEventListener != null) {
        container.addEventListener("ContainerModified", function(e) {
			ContainerChanged(container);
        }, false);
    } else container.attachEvent("onpropertychange", function(e) {
			ContainerChanged(container);
    });

}).call(YandexNamespace);

